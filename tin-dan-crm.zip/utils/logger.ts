export class Logger {
  static info(message: string, ...args: any[]) {
    console.log(`[Tín Dân AI Engine] INFO: ${message}`, ...args);
  }

  static warn(message: string, ...args: any[]) {
    console.warn(`[Tín Dân AI Engine] WARN: ${message}`, ...args);
  }

  static error(message: string, ...args: any[]) {
    console.error(`[Tín Dân AI Engine] ERROR: ${message}`, ...args);
  }
}

import { Logger } from './logger';

export interface RetryOptions {
  retries?: number;
  initialDelayMs?: number;
  factor?: number;
  timeoutMs?: number;
}

/**
 * Executes an async operation with a strict timeout and automatic retry logic for transient errors.
 */
export async function withRetryAndTimeout<T>(
  fn: (signal: AbortSignal) => Promise<T>,
  options: RetryOptions = {}
): Promise<T> {
  const retries = options.retries ?? 2; // Maximum 2 retries (up to 3 total attempts)
  const initialDelayMs = options.initialDelayMs ?? 1500;
  const factor = options.factor ?? 2;
  const timeoutMs = options.timeoutMs ?? 45000; // 45s request timeout

  let delay = initialDelayMs;
  let lastError: any;

  for (let attempt = 0; attempt <= retries; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => {
      controller.abort();
    }, timeoutMs);

    try {
      const result = await fn(controller.signal);
      clearTimeout(timer);
      return result;
    } catch (err: any) {
      clearTimeout(timer);
      lastError = err;

      const isTimeout = err?.name === 'AbortError';
      const status = err?.status || (err?.response ? err.response.status : 0);
      const errMsg = String(err?.message || err || "").toLowerCase();

      let formattedMsg = errMsg;
      if (isTimeout) {
        formattedMsg = `HuggingFace API request timed out after ${timeoutMs}ms`;
      } else if (status) {
        formattedMsg = `HTTP Error ${status}: ${errMsg}`;
      }

      const isTransient =
        isTimeout ||
        status === 429 ||
        status === 500 ||
        status === 502 ||
        status === 503 ||
        status === 504 ||
        errMsg.includes("503") ||
        errMsg.includes("429") ||
        errMsg.includes("500") ||
        errMsg.includes("502") ||
        errMsg.includes("504") ||
        errMsg.includes("temporary") ||
        errMsg.includes("high demand") ||
        errMsg.includes("overloaded") ||
        errMsg.includes("rate limit") ||
        errMsg.includes("timeout") ||
        errMsg.includes("abort");

      // Stop immediately on fatal auth errors
      const isFatalAuth = status === 401 || status === 403 || errMsg.includes("unauthorized") || errMsg.includes("invalid key");

      if (isTransient && !isFatalAuth && attempt < retries) {
        Logger.warn(`Transient error encountered: ${formattedMsg}. Retrying in ${delay}ms... (Attempt ${attempt + 1}/${retries})`);
        await new Promise((resolve) => setTimeout(resolve, delay));
        delay *= factor;
      } else {
        throw new Error(formattedMsg);
      }
    }
  }

  throw lastError;
}

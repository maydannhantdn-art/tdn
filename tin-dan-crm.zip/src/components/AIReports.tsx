/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { User, Task, KPIs, Department } from '../types';
import { DB } from '../lib/dataStore';
import * as XLSX from 'xlsx';
import { 
  FileCheck, 
  Download, 
  Printer, 
  Sparkles, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle, 
  PieChart,
  BarChart,
  FileBox,
  CornerDownRight
} from 'lucide-react';

interface AIReportsProps {
  currentUser: User;
  tasks: Task[];
  kpis: KPIs[];
}

export default function AIReports({ currentUser, tasks, kpis }: AIReportsProps) {
  const [reportType, setReportType] = useState<'daily' | 'weekly' | 'monthly'>('weekly');
  const [aiReportOutput, setAiReportOutput] = useState('');
  const [loadingReport, setLoadingReport] = useState(false);

  // Compute stats
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter(t => t.status === 'Done').length;
  const overdueTasks = tasks.filter(t => t.overdueRisk).length;
  const completionRate = Math.round((completedTasks / (totalTasks || 1)) * 100);

  const generateAIReport = async () => {
    setLoadingReport(true);
    setAiReportOutput('');
    try {
      const res = await fetch('/api/ai/generate-summary', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tasks, kpis, reportType })
      });
      const data = await res.json();
      if (data.success) {
        setAiReportOutput(data.summary);
      } else {
        setAiReportOutput('Không kết nối được dịch vụ AI. Hãy sử dụng mẫu báo cáo tích hợp cục bộ.');
      }
    } catch {
      setAiReportOutput('Lỗi xử lý báo cáo. Vui lòng thử lại sau.');
    } finally {
      setLoadingReport(false);
    }
  };

  // Real native Excel Weekly Exporter (All columns)
  const exportWeeklyExcel = () => {
    const dataList = tasks.map((t, idx) => ({
      'STT': idx + 1,
      'Mã Công Việc': t.id,
      'Tên Tác Vụ': t.title,
      'Mô Tả Chi Tiết': t.description || 'Không có mô tả',
      'Nhân Sự Thực Hiện': t.assignee,
      'Phòng Ban Vận Hành': t.department,
      'Độ Ưu Tiên': t.priority,
      'Trạng Thái Hiện Tại': t.status,
      'Hạn Chót Bàn Giao': t.deadline,
      'Sự Kiện Kế Hoạch Tuần': t.planWeek || 'Week 1',
      'Tháng Lên Kế Hoạch': t.planMonth || 'June',
      'Điểm KPI Chỉ Định': t.kpiScore,
      'Dự Án / Chiến Dịch Trực Thuộc': t.projectName || 'Không có dự án liên kết',
      'Ngày Khởi Tạo Tác Vụ': t.createdAtDate || '2026-06-01'
    }));

    const worksheet = XLSX.utils.json_to_sheet(dataList);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Báo cáo Tuần');
    
    // Auto column resizing
    worksheet['!cols'] = [
      { wch: 6 },
      { wch: 15 },
      { wch: 35 },
      { wch: 30 },
      { wch: 20 },
      { wch: 20 },
      { wch: 12 },
      { wch: 15 },
      { wch: 15 },
      { wch: 20 },
      { wch: 20 },
      { wch: 15 },
      { wch: 30 },
      { wch: 15 }
    ];

    XLSX.writeFile(workbook, `TIN_DAN_CRM_Bao_Cao_Tuan_Day_Du_Cot_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  // Real native Excel Monthly Exporter (Replicating Corporate Layout)
  const exportMonthlyExcel = () => {
    const dataList = kpis.map((k, idx) => {
      const percentage = Math.round((k.completedTasks / (k.totalTasks || 1)) * 100);
      let classification = 'Yếu';
      if (percentage >= 90) classification = 'Xuất Sắc';
      else if (percentage >= 75) classification = 'Tốt';
      else if (percentage >= 50) classification = 'Khá';
      else if (percentage >= 35) classification = 'Trung Bình';

      return {
        'STT': idx + 1,
        'Họ và Tên Nhân Sự': k.employeeName,
        'Phòng Ban Chuyên Trách': k.department,
        'Tháng Báo Cáo': k.month || 'Tháng 6',
        'Tổng Việc Được Phân Công': k.totalTasks,
        'Đầu Việc Đã Về Đích': k.completedTasks,
        'Đầu Việc Trễ Hạn, Nghẽn Lỗi': k.overdueTasks,
        'Tỷ Lệ Hoàn Thành (%)': percentage + '%',
        'Tổng Điểm KPI Đã Đạt Bản Tháng': k.kpiScore,
        'Xếp Loại Hiệu Năng Hoạt Động': classification,
        'Nhận Xét / Đánh Giá Thẩm Định': k.notes || 'Đã hoàn thành tốt nhiệm vụ được giao'
      };
    });

    const worksheet = XLSX.utils.json_to_sheet(dataList);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'KPI Tháng');

    worksheet['!cols'] = [
      { wch: 6 },
      { wch: 22 },
      { wch: 20 },
      { wch: 12 },
      { wch: 22 },
      { wch: 20 },
      { wch: 22 },
      { wch: 20 },
      { wch: 25 },
      { wch: 25 },
      { wch: 40 }
    ];

    XLSX.writeFile(workbook, `TIN_DAN_CRM_Bao_Cao_Thang_KPI_Bieu_Mau_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  // PDF layout utilizes standard window.print formatted beautifully
  const triggerPrintPDF = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    printWindow.document.write(`
      <html>
        <head>
          <title>Báo cáo Tín Dân CRM</title>
          <style>
            body { font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; padding: 40px; color: #333; line-height: 1.6; }
            h1 { font-size: 24px; text-align: center; color: #1e3a8a; margin-bottom: 5px; }
            h2 { font-size: 14px; text-align: center; color: #666; font-weight: normal; margin-bottom: 30px; }
            .section { margin-bottom: 25px; }
            h3 { border-bottom: 2px solid #5a67d8; padding-bottom: 5px; font-size: 16px; color: #2d3748; }
            table { width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 12px; }
            th, td { border: 1px solid #e2e8f0; padding: 10px; text-align: left; }
            th { background-color: #f7fafc; color: #4a5568; }
            .kpi-badge { font-weight: bold; color: #38a169; }
            .footer { margin-top: 50px; font-size: 10px; text-align: center; color: #a0aec0; border-top: 1px dashed #e2e8f0; padding-top: 15px; }
          </style>
        </head>
        <body>
          <h1>BÁO CÁO HIỆU NĂNG VẬN HÀNH DOANH NGHIỆP</h1>
          <h2>Công ty TNHH Tín Dân - Thời gian xuất: ${new Date().toLocaleDateString('vi-VN')}</h2>
          
          <div class="section">
            <h3>I. Chỉ số vận hành chung</h3>
            <p>Tổng số đầu việc phân công sản xuất: <strong>${totalTasks}</strong></p>
            <p>Đầu việc đã hoàn thành cam kết: <strong>${completedTasks} (${completionRate}%)</strong></p>
            <p>Đầu việc trễ hạn cảnh báo: <strong>${overdueTasks}</strong></p>
          </div>

          <div class="section">
            <h3>II. Xếp hạng KPI nhân sự</h3>
            <table>
              <thead>
                <tr>
                  <th>Nhân viên</th>
                  <th>Phòng ban</th>
                  <th>Tổng việc</th>
                  <th>Đã xong</th>
                  <th>Quá hạn</th>
                  <th>Điểm số KPI</th>
                </tr>
              </thead>
              <tbody>
                ${kpis.map(k => `
                  <tr>
                    <td>${k.employeeName}</td>
                    <td>${k.department}</td>
                    <td>${k.totalTasks}</td>
                    <td>${k.completedTasks}</td>
                    <td>${k.overdueTasks}</td>
                    <td class="kpi-badge">${k.kpiScore}đ</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>

          <div class="footer">
            Báo cáo trích xuất tự động từ hệ thống Tín Dân CRM OS. Bản quyền thuộc về Tín Dân Company.
          </div>
          <script>
            window.onload = function() { window.print(); }
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto p-4 md:p-6 lg:p-8 font-sans">
      
      {/* Title */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white font-display">AI Báo Cáo Hiệu Năng</h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Xuất các bản kiểm tra năng lượng hoạt động và phân tách KPI cho phòng ban.</p>
        </div>

        {/* Top controls toggle */}
        <div className="flex gap-2">
          <button
            onClick={() => setReportType('daily')}
            className={`py-1.5 px-3 text-xs rounded-lg font-bold transition-all cursor-pointer ${
              reportType === 'daily' ? 'bg-blue-600 text-white shadow-sm font-bold' : 'bg-slate-100 dark:bg-slate-800 text-slate-600'
            }`}
          >
            Báo cáo Ngày
          </button>
          <button
            onClick={() => setReportType('weekly')}
            className={`py-1.5 px-3 text-xs rounded-lg font-bold transition-all cursor-pointer ${
              reportType === 'weekly' ? 'bg-blue-600 text-white shadow-sm font-bold' : 'bg-slate-100 dark:bg-slate-800 text-slate-600'
            }`}
          >
            Báo cáo Tuần
          </button>
          <button
            onClick={() => setReportType('monthly')}
            className={`py-1.5 px-3 text-xs rounded-lg font-bold transition-all cursor-pointer ${
              reportType === 'monthly' ? 'bg-blue-600 text-white shadow-sm font-bold' : 'bg-slate-100 dark:bg-slate-800 text-slate-600'
            }`}
          >
            Báo cáo Tháng
          </button>
        </div>
      </div>

      {/* Grid counters & Printable exports buttons layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left hand: stats overview diagrams */}
        <div className="lg:col-span-5 space-y-6">
          <div className="glass-card rounded-2xl p-5 space-y-4">
            <h2 className="text-sm font-bold font-display text-slate-800 dark:text-white uppercase tracking-wider">Chỉ số Hoàn thành</h2>
            
            {/* Beautiful SVG donut chart */}
            <div className="flex items-center justify-around gap-4 py-4">
              <div className="relative w-32 h-32 flex items-center justify-center">
                <svg className="w-full h-full -rotate-90">
                  <circle cx="64" cy="64" r="50" fill="transparent" stroke="#f1f5f9" strokeWidth="10" />
                  <circle 
                    cx="64" 
                    cy="64" 
                    r="50" 
                    fill="transparent" 
                    stroke="#3b82f6" 
                    strokeWidth="10" 
                    strokeDasharray={314} 
                    strokeDashoffset={314 - (314 * completionRate) / 100}
                    strokeLinecap="round"
                  />
                </svg>
                <div className="absolute flex flex-col items-center">
                  <span className="text-xl font-bold text-slate-800 dark:text-white font-mono">{completionRate}%</span>
                  <span className="text-[9px] text-slate-400">Cam kết</span>
                </div>
              </div>

              <div className="text-xs space-y-2">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-500 block" />
                  <span>Đã Xong: <b>{completedTasks}</b></span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-red-500 block animate-pulse" />
                  <span>Quá Hạn: <b>{overdueTasks}</b></span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-slate-200 block" />
                  <span>Tổng Việc: <b>{totalTasks}</b></span>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Export actionable options */}
          <div className="glass-card rounded-2xl p-5 space-y-4">
            <h2 className="text-sm font-bold font-display text-slate-800 dark:text-white uppercase tracking-wider">Kênh Kết Xuất Dữ Liệu</h2>
            <p className="text-[11px] text-slate-400">Xuất file chuyên nghiệp hỗ trợ in hoặc lưu trữ cục bộ chỉ với 1-click.</p>
            
            <div className="flex flex-col gap-2.5">
              <button
                onClick={exportWeeklyExcel}
                className="w-full py-2 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/20 dark:hover:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300 text-xs font-bold rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer border border-emerald-250 dark:border-emerald-800"
              >
                <Download className="w-4 h-4 text-emerald-500" />
                <span>Xuất Báo cáo Tuần đầy đủ cột (Excel .xlsx)</span>
              </button>

              <button
                onClick={exportMonthlyExcel}
                className="w-full py-2 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/20 dark:hover:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 text-xs font-bold rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer border border-indigo-250 dark:border-indigo-800"
              >
                <Download className="w-4 h-4 text-indigo-500" />
                <span>Xuất Báo cáo Tháng quy chuẩn (Excel .xlsx)</span>
              </button>

              <button
                onClick={triggerPrintPDF}
                className="w-full py-2 bg-slate-50 hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-750 text-slate-750 dark:text-slate-300 text-xs font-semibold rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer border border-slate-250 dark:border-slate-700"
              >
                <Printer className="w-4 h-4" />
                <span>Xuất file Báo cáo PDF (Mở trang in)</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right hand: AI reports analysis outputs */}
        <div className="lg:col-span-7">
          <div className="glass-card shadow-xl rounded-2xl overflow-hidden min-h-[440px] flex flex-col justify-between border-blue-200/30 dark:border-slate-800/80">
            <div>
              <div className="bg-gradient-to-r from-blue-700 to-indigo-800 px-5 py-4 text-white flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-yellow-300 fill-yellow-300" />
                  <span className="font-bold text-xs font-display tracking-wide uppercase">AI TÍN DÂN REPORTS GENERATOR CORPS</span>
                </div>
                <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded font-mono">Bản Tuần & Tháng</span>
              </div>

              <div className="p-5 font-sans leading-relaxed text-sm max-h-[380px] overflow-y-auto">
                {loadingReport ? (
                  <div className="py-24 text-center text-slate-500 space-y-3">
                    <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent animate-spin rounded-full mx-auto" />
                    <p className="text-xs font-mono">Qwen AI đang đọc bảng biểu, phân tích hiệu suất xưởng in tem...</p>
                  </div>
                ) : aiReportOutput ? (
                  <div className="prose dark:prose-invert text-xs leading-relaxed max-w-none text-slate-750 whitespace-pre-line">
                    {aiReportOutput}
                  </div>
                ) : (
                  <div className="py-24 text-center text-slate-400 space-y-3">
                    <FileBox className="w-10 h-10 mx-auto text-slate-300 dark:text-slate-800" />
                    <p className="text-xs max-w-xs mx-auto text-slate-400 leading-relaxed font-light">Chưa tạo báo cáo vận hành. Bấm nút "Tổng Hợp Báo Cáo Bằng AI" bên dưới để khởi tạo chẩn đoán tức thời.</p>
                  </div>
                )}
              </div>
            </div>

            {/* Generate Trigger */}
            <div className="p-4 bg-white/5 dark:bg-black/20 border-t border-white/5">
              <button
                type="button"
                onClick={generateAIReport}
                disabled={loadingReport}
                className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 text-white font-semibold text-xs rounded-xl flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-yellow-300 fill-yellow-300" />
                <span>{loadingReport ? 'Sử dụng Hugging Face Qwen-72B...' : 'Tổng Hợp Báo Cáo Bằng AI (Hugging Face Qwen-72B)'}</span>
              </button>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
}

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { User } from '../types';
import { Sparkles, Send, Bot, RefreshCw, Layers, ShieldAlert, FileText, Compass } from 'lucide-react';
import { DB } from '../lib/dataStore';

interface AIAssistantProps {
  currentUser: User;
}

interface Message {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: Date;
}

export default function AIAssistant({ currentUser }: AIAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      sender: 'ai',
      text: `Xin chào sếp **${currentUser.name}**! Em là Tín Dân AI, trợ lý ảo chuyên trách hỗ trợ tối ưu hóa quy trình xưởng in Tem Vivian và quản trị KPI hiệu năng. 
      
Sếp có thể hỏi em bất cứ điều gì liên quan đến:
- Tối ưu hóa phân công công việc phòng ban.
- Phân tích rủi ro trễ hạn lô hàng cuộn sấy UV.
- Đề xuất tăng sao hoặc cải thiện chỉ số KPI nhân sự.
- Soạn thảo mẫu kế hoạch tổng thể tuần tới.`,
      timestamp: new Date()
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const handleSend = async (e?: React.FormEvent, customPrompt?: string) => {
    if (e) e.preventDefault();
    const promptToSend = customPrompt || inputText;
    if (!promptToSend.trim()) return;

    // Add user message
    const userMsg: Message = {
      id: 'm_' + Date.now(),
      sender: 'user',
      text: promptToSend,
      timestamp: new Date()
    };
    setMessages(prev => [...prev, userMsg]);
    if (!customPrompt) setInputText('');
    
    setIsTyping(true);

    try {
      const messagesToSend = [...messages, userMsg].map(m => ({
        sender: m.sender,
        content: m.text
      }));

      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: messagesToSend,
          currentDataState: {
            projects: DB.getProjects(),
            tasks: DB.getTasks(),
            users: DB.getUsers()
          }
        })
      });

      const data = await res.json();
      if (data.success) {
        setMessages(prev => [...prev, {
          id: 'ai_' + Date.now(),
          sender: 'ai',
          text: data.response || data.reply,
          timestamp: new Date()
        }]);
      } else {
        setMessages(prev => [...prev, {
          id: 'ai_err_' + Date.now(),
          sender: 'ai',
          text: 'Rất tiếc, bộ vi xử lý AI Tín Dân đang gặp bận rộn tạm thời hoặc thiếu cấu hình GEMINI_API_KEY. Sếp có thể liên hệ bộ phận IT hoặc quản trị viên hệ thống để kiểm tra.',
          timestamp: new Date()
        }]);
      }
    } catch {
      setMessages(prev => [...prev, {
        id: 'ai_neterr_' + Date.now(),
        sender: 'ai',
        text: 'Có lỗi kết nối mạng xảy ra. Không thể liên kết dữ liệu với đầu não 5001.',
        timestamp: new Date()
      }]);
    } finally {
      setIsTyping(false);
    }
  };

  const suggestions = [
    { label: 'Quy trình in sấy UV Tem Vivian', icon: FileText, text: 'Hãy giải thích tiêu chuẩn vận hành bảo trì đầu UV máy in mác dán Vivian' },
    { label: 'Gợi ý nâng sao KPI phòng Sale', icon: Layers, text: 'Khách hàng lấy sỉ phàn nàn phản hồi chậm, hãy viết kịch bản tối ưu KPI phòng Sale chăm sóc tự động' },
    { label: 'Dự thảo kế hoạch in decal tuần', icon: Compass, text: 'Lập mẫu tiến độ phân chia lô hàng decal cuộn tuần tới cho bộ phận Kho và Kỹ Thuật' }
  ];

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-6 lg:p-8 font-sans h-[calc(100vh-140px)] flex flex-col justify-between">
      
      {/* Visual Header bar */}
      <div className="glass-card p-4 rounded-t-2xl flex items-center justify-between border-b-x-0 border-b-none border-b-0">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-blue-600 text-white rounded-xl shadow-md shadow-blue-500/10">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold font-display text-slate-850 dark:text-white uppercase tracking-wider block">Trợ lý Chiến lược Tín Dân AI</h2>
            <p className="text-[10px] text-slate-400 font-mono">Powered by Google Gemini 3.5-Flash</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2 text-[10px] bg-slate-100 dark:bg-slate-800 py-1 px-2.5 rounded-lg text-slate-500">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
          <span>Sẵn sàng kết nối</span>
        </div>
      </div>

      {/* Message Output dialog scrolling box */}
      <div className="flex-1 bg-white/2 dark:bg-slate-900/10 border-x border-b border-white/5 p-5 overflow-y-auto space-y-4 backdrop-blur-md">
        {messages.map((m) => {
          const isAi = m.sender === 'ai';
          return (
            <div
              key={m.id}
              className={`flex gap-3 max-w-[85%] ${isAi ? '' : 'ml-auto flex-row-reverse'}`}
            >
              <div className={`p-2 rounded-xl shrink-0 h-max ${
                isAi 
                  ? 'bg-blue-50 text-blue-600 dark:bg-slate-800 dark:text-blue-400' 
                  : 'bg-indigo-50 text-indigo-600 dark:bg-blue-950/30'
              }`}>
                {isAi ? <Bot className="w-4 h-4" /> : <span className="text-[10px] font-bold">BẠN</span>}
              </div>

              <div className={`p-4 rounded-2xl text-xs leading-relaxed font-sans ${
                isAi 
                  ? 'bg-white/5 dark:bg-slate-800/20 border border-white/5 text-slate-800 dark:text-slate-200' 
                  : 'bg-blue-600 text-white shadow-md shadow-blue-500/5'
              }`}>
                <div className="prose dark:prose-invert max-w-none text-slate-800 dark:text-slate-100 whitespace-pre-wrap">
                  {m.text}
                </div>
                <span className="text-[8px] font-mono mt-2 block opacity-40 text-right">
                  {m.timestamp.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            </div>
          );
        })}

        {isTyping && (
          <div className="flex gap-3 max-w-[80%]">
            <div className="p-2 bg-blue-50 text-blue-600 rounded-xl shrink-0">
              <Bot className="w-4 h-4" />
            </div>
            <div className="p-3 bg-white/5 dark:bg-slate-800/20 border border-white/5 rounded-2xl flex items-center gap-1">
              <div className="w-1.5 h-1.5 bg-blue-600 rounded-full animate-bounce [animation-delay:-0.3s]" />
              <div className="w-1.5 h-1.5 bg-blue-600 rounded-full animate-bounce [animation-delay:-0.15s]" />
              <div className="w-1.5 h-1.5 bg-blue-600 rounded-full animate-bounce" />
            </div>
          </div>
        )}

        <div ref={scrollRef} />
      </div>

      {/* Suggests prompt widgets row - visible only when scroll is short */}
      {messages.length < 3 && (
        <div className="bg-white/2 dark:bg-slate-900/10 border-x border-white/5 p-3.5 space-y-2 backdrop-blur-md">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Gợi ý chủ đề nhanh:</span>
          <div className="flex flex-col sm:flex-row gap-2">
            {suggestions.map((s, idx) => {
              const Icon = s.icon;
              return (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleSend(undefined, s.text)}
                  className="flex-1 text-left p-2.5 border border-white/5 hover:border-blue-500 bg-white/5 dark:bg-black/10 hover:bg-white/10 rounded-xl flex items-start gap-2 text-[10px] transition-all cursor-pointer font-light"
                >
                  <Icon className="w-3.5 h-3.5 text-blue-500 shrink-0 mt-0.5" />
                  <span className="text-slate-600 line-clamp-2">{s.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Input Message panel */}
      <form
        onSubmit={handleSend}
        className="glass-card p-4 rounded-b-2xl border-t-0 flex gap-2.5"
      >
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Hỏi trợ lý về tiến trình in Tem Vivian, sửa KPI..."
          className="flex-1 glass-input focus:outline-none focus:ring-2 focus:ring-blue-550 px-4 py-2.5 rounded-xl text-xs text-slate-800 dark:text-white"
        />
        <button
          type="submit"
          className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-5 rounded-xl flex items-center justify-center gap-1 text-xs shadow-md cursor-pointer"
        >
          <Send className="w-3.5 h-3.5" />
          <span>Gửi tin</span>
        </button>
      </form>

    </div>
  );
}

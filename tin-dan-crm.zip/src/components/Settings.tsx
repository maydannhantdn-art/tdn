/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { User, ThemeMode } from '../types';
import { DB } from '../lib/dataStore';
import { Settings as SettingsIcon, Sliders, HardDrive, Palette, Sparkles, CheckCircle2, ShieldAlert, Key } from 'lucide-react';

interface SettingsProps {
  currentUser: User;
  themeMode: ThemeMode;
  setThemeMode: (mode: ThemeMode) => void;
  onAddNotification: (title: string, content: string, type: string) => void;
}

export default function Settings({ currentUser, themeMode, setThemeMode, onAddNotification }: SettingsProps) {
  const [targetKPI, setTargetKPI] = useState<number>(100);
  const [modelName, setModelName] = useState('qwen-72b');
  const [adminBypass, setAdminBypass] = useState(true);
  const [showConfigAlert, setShowConfigAlert] = useState('');

  // Password alteration state hooks
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [passError, setPassError] = useState('');
  const [passSuccess, setPassSuccess] = useState('');

  const handleUpdatePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPass) {
      setPassError('Vui lòng điền mật khẩu mới!');
      return;
    }
    if (newPass !== confirmPass) {
      setPassError('Mật khẩu nhập lại không khớp!');
      return;
    }

    const allUsers = DB.getUsers();
    const updatedUsers = allUsers.map(u => {
      if (u.id === currentUser.id) {
        return { ...u, password: newPass };
      }
      return u;
    });

    DB.saveUsers(updatedUsers);

    // Persist session-active attributes
    const updatedCurrentUser = { ...currentUser, password: newPass };
    DB.setCurrentUser(updatedCurrentUser);

    setPassError('');
    setPassSuccess('Đã đổi mật khẩu cá nhân của sếp thành công!');
    setNewPass('');
    setConfirmPass('');

    onAddNotification(
      'Cập nhật mật khẩu bảo mật',
      `Sếp ${currentUser.name} vừa thiết lập trực tiếp mật khẩu bảo vệ mới.`,
      'settings'
    );

    setTimeout(() => {
      setPassSuccess('');
    }, 4000);
  };

  const saveConfigurations = (e: React.FormEvent) => {
    e.preventDefault();
    setShowConfigAlert('Đã cập nhật cấu hình tham số xưởng in Tem Vivian vào lõi Tín Dân CRM!');
    
    // Add positive tracking
    onAddNotification(
      'Cập nhật cấu hình hệ thống',
      `Sếp ${currentUser.name} vừa cập nhật KPI kế hoạch là ${targetKPI}đ và cấu hình AI model: ${modelName}.`,
      'settings'
    );

    setTimeout(() => {
      setShowConfigAlert('');
    }, 4000);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto p-4 md:p-6 lg:p-8 font-sans">
      
      {/* Title */}
      <div>
        <h1 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white font-display">Cấu Hình Quản Trị Hệ Thống</h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Vùng hiệu chỉnh tham số, mô hình AI điều phối, và thông số KPI tháng của Tín Dân CRM.</p>
      </div>

      {showConfigAlert && (
        <div className="p-3.5 bg-emerald-50 text-emerald-600 border border-emerald-250 text-xs rounded-xl flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          <span>{showConfigAlert}</span>
        </div>
      )}

      {/* Settings Panel Grid */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        
        {/* Left column - main settings forms */}
        <div className="md:col-span-8">
          <div className="glass-card rounded-2xl p-6 space-y-6">
            
            {/* Visual themes section */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold font-display uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-2">
                <Palette className="w-4 h-4 text-blue-500" />
                <span>Môi trường và Giao diện</span>
              </h3>

              <div className="grid grid-cols-3 gap-3">
                {Object.values(ThemeMode).map((mode) => (
                  <button
                    key={mode}
                    type="button"
                    onClick={() => setThemeMode(mode)}
                    className={`py-2 px-3 border rounded-xl text-xs font-semibold text-center transition-all ${
                      themeMode === mode 
                        ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-600/10' 
                        : 'bg-slate-150 text-slate-600 border-slate-200/60 font-medium'
                    }`}
                  >
                    {mode === ThemeMode.LIGHT ? 'Sáng (Light)' : mode === ThemeMode.DARK ? 'Sẫm (Dark)' : 'Kết nối máy'}
                  </button>
                ))}
              </div>
            </div>

            {/* Target parameters */}
            <div className="space-y-3 border-t border-slate-100 dark:border-slate-800 pt-5">
              <h3 className="text-xs font-bold font-display uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-2">
                <Sliders className="w-4 h-4 text-blue-500" />
                <span>Thông số KPI quy chuẩn tháng</span>
              </h3>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1.5">Mục tiêu KPI cá nhân</label>
                  <input
                    type="number"
                    value={targetKPI}
                    onChange={(e) => setTargetKPI(parseInt(e.target.value) || 100)}
                    className="w-full glass-input rounded-lg py-2 px-3 text-xs text-slate-800 dark:text-slate-200 font-bold font-mono"
                  />
                  <span className="text-[10px] text-slate-400 mt-1 block">Mẫu kpi lý tưởng hoàn thành.</span>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1.5">Mô hình AI chỉ định (Hugging Face)</label>
                  <select
                    value={modelName}
                    onChange={(e) => setModelName(e.target.value)}
                    className="w-full glass-dropdown rounded-lg py-2 px-3 text-xs text-slate-800 dark:text-slate-200 font-bold focus:outline-none"
                  >
                    <option value="qwen-72b">Hugging Face Qwen-72B (Chính xác)</option>
                    <option value="qwen-32b">Hugging Face Qwen-32B (Tốc độ cao)</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Change Password Block */}
            <div className="space-y-4 border-t border-slate-100 dark:border-slate-800 pt-5">
              <h3 className="text-xs font-bold font-display uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-2">
                <Key className="w-4 h-4 text-emerald-500" />
                <span>Bảo mật & Thiết lập Mật khẩu thiết bị</span>
              </h3>

              <form onSubmit={handleUpdatePassword} className="space-y-3">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">Mật khẩu mới</label>
                    <input
                      type="password"
                      value={newPass}
                      onChange={(e) => setNewPass(e.target.value)}
                      placeholder="Nhập mật khẩu mới"
                      className="w-full bg-slate-50 dark:bg-slate-850/50 border border-slate-200 dark:border-slate-800 rounded-lg text-xs py-2 px-3 text-slate-800 dark:text-white focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">Xác nhận mật khẩu</label>
                    <input
                      type="password"
                      value={confirmPass}
                      onChange={(e) => setConfirmPass(e.target.value)}
                      placeholder="Xác thực mật khẩu"
                      className="w-full bg-slate-50 dark:bg-slate-850/50 border border-slate-200 dark:border-slate-800 rounded-lg text-xs py-2 px-3 text-slate-800 dark:text-white focus:outline-none"
                    />
                  </div>
                </div>

                {passError && (
                  <p className="text-rose-500 text-[11px] font-semibold">{passError}</p>
                )}
                {passSuccess && (
                  <p className="text-emerald-500 text-[11px] font-semibold">{passSuccess}</p>
                )}

                <div className="flex justify-start">
                  <button
                    type="submit"
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-[11px] rounded-lg cursor-pointer shadow-sm transition-all"
                  >
                    Cập nhật mật khẩu bảo mật
                  </button>
                </div>
              </form>
            </div>

            {/* Administrator switches */}
            <div className="space-y-3 border-t border-slate-100 dark:border-slate-800 pt-5 text-xs text-slate-700">
              <label className="flex items-center gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={adminBypass}
                  onChange={(e) => setAdminBypass(e.target.checked)}
                  className="w-4 h-4 accent-blue-600 rounded"
                />
                <span className="font-semibold">Kích hoạt chế độ gộp dữ liệu KPI liên phòng ban</span>
              </label>
              <p className="text-[10px] text-slate-400 pl-6">Cho phép quản lý trực thuộc xem chéo tiến độ sấy UV decal và doanh thu Sale để tối ưu phân công liên phòng ban.</p>
            </div>

            {/* Form submit */}
            <div className="pt-4 border-t border-white/5 flex justify-end text-xs">
              <button
                type="button"
                onClick={saveConfigurations}
                className="py-2.5 px-6 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-md cursor-pointer"
              >
                Lưu Thay Đổi Cấu Hình
              </button>
            </div>

          </div>
        </div>

        {/* Right column - profile dashboard info card */}
        <div className="md:col-span-4 space-y-4">
          <div className="glass-card rounded-2xl p-5 text-xs space-y-4">
            
            <div className="flex items-center gap-2 font-bold font-display uppercase tracking-wider text-slate-800 dark:text-white">
              <SettingsIcon className="w-4 h-4 text-slate-500" />
              <span>Cá nhân sở tại</span>
            </div>

            <div className="space-y-1">
              <span className="text-slate-400 block">Tên nhân viên:</span>
              <span className="font-bold text-slate-900 dark:text-white block">{currentUser.name}</span>
            </div>

            <div className="space-y-1">
              <span className="text-slate-400 block">Phòng ban làm việc:</span>
              <span className="font-bold text-blue-600 block">Phòng {currentUser.department}</span>
            </div>

            <div className="space-y-1">
              <span className="text-slate-400 block">Cấp bậc hệ thống:</span>
              <span className="font-bold text-slate-900 dark:text-white block">{currentUser.role}</span>
            </div>

            <div className="p-3 bg-blue-50/10 border border-blue-200/25 rounded-xl space-y-1 leading-relaxed text-[10px] text-blue-600 dark:text-blue-400">
              <div className="flex items-center gap-1.5 font-bold uppercase">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Quyền hạn tối đa</span>
              </div>
              <p>Tài khoản của bạn có đủ thẩm quyền phê duyệt kế hoạch, thưởng thêm điểm KPI, nạp kế hoạch in tự động và cấu hình AI.</p>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
}

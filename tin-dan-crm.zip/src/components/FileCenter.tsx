/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { User } from '../types';
import { FileBox, FileText, Download, ExternalLink, PlusSquare, Search, HardDrive, Info } from 'lucide-react';

interface FileCenterProps {
  currentUser: User;
}

export default function FileCenter({ currentUser }: FileCenterProps) {
  const [search, setSearch] = useState('');
  const [uploadMsg, setUploadMsg] = useState('');
  
  const [docs, setDocs] = useState([
    { id: '1', title: 'Quy chuẩn Máy Sấy Khô UV Vivian v2.1', type: 'PDF', size: '2.4 MB', folder: 'Kỹ thuật', date: '2026-05-12', author: 'Trần Minh Đức' },
    { id: '2', title: 'Thiết Kế Decal Nhãn Cuộn 3 Lớp VF5 Red', type: 'AI (Illustrator)', size: '14.8 MB', folder: 'Marketing', date: '2026-06-01', author: 'Nguyễn Văn Nam' },
    { id: '3', title: 'Biên Bản Họp Giao Việc Đầu Tháng 6 - GĐ Tuấn Anh', type: 'Word (.docx)', size: '420 KB', folder: 'Admin', date: '2026-06-02', author: 'Trần Tuấn Anh' },
    { id: '4', title: 'Bảng Báo Giá Phôi Nhãn Decal Chống Giả', type: 'Excel (.xlsx)', size: '1.2 MB', folder: 'Sale', date: '2026-05-28', author: 'Lê Thị Thuỷ' }
  ]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const file = files[0];
      const newDoc = {
        id: 'doc_' + Date.now(),
        title: file.name.split('.')[0],
        type: file.name.split('.').pop()?.toUpperCase() || 'FILE',
        size: `${Math.round(file.size / 1024)} KB`,
        folder: currentUser.department,
        date: new Date().toISOString().split('T')[0],
        author: currentUser.name
      };

      setDocs([newDoc, ...docs]);
      setUploadMsg(`Đã tải lên và lưu vào đám mây tài liệu "${file.name}"!`);
      setTimeout(() => setUploadMsg(''), 4000);
    }
  };

  const filteredDocs = docs.filter(d => d.title.toLowerCase().includes(search.toLowerCase()) || d.folder.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-6 max-w-7xl mx-auto p-4 md:p-6 lg:p-8 font-sans">
      
      {/* Title */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white font-display">Tài Liệu Xưởng & Thư Viện Đám Mây</h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Kho lưu trữ quy chuẩn thiết kế màng decal, máy in cuộn UV, và tài liệu phân công.</p>
        </div>

        {/* Upload action button inline */}
        <div className="relative w-full sm:w-auto">
          <label className="w-full sm:w-auto py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 cursor-pointer shadow-md transition-all">
            <PlusSquare className="w-4 h-4" />
            <span>Tải Lên File Quy Chuẩn</span>
            <input
              type="file"
              onChange={handleFileUpload}
              className="absolute inset-0 opacity-0 cursor-pointer w-0 h-0"
            />
          </label>
        </div>
      </div>

      {uploadMsg && (
        <div className="p-3 bg-emerald-50 text-emerald-600 border border-emerald-200 text-xs rounded-xl">
          {uploadMsg}
        </div>
      )}

      {/* Grid columns */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left hand: directories list */}
        <div className="lg:col-span-8 space-y-4">
          <div className="glass-card rounded-2xl p-5 space-y-4">
            
            {/* Search filter docs */}
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Tìm tên tài liệu, đuôi định dạng, thư mục phòng ban..."
                className="w-full glass-input rounded-lg text-xs py-2 pl-9 pr-4 focus:outline-none"
              />
            </div>

            {/* Document listings stack table */}
            <div className="space-y-3 max-h-[420px] overflow-y-auto pr-1">
              {filteredDocs.length === 0 ? (
                <p className="p-8 text-center text-slate-400 text-xs italic">Không tìm thấy tài liệu phù hợp.</p>
              ) : (
                filteredDocs.map((doc) => (
                  <div
                    key={doc.id}
                    className="p-3.5 border border-white/5 rounded-xl hover:border-blue-500 bg-white/5 dark:bg-black/20 flex items-center justify-between gap-4 text-xs transition-all"
                  >
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 bg-blue-50 dark:bg-blue-900/20 text-blue-600 rounded-lg">
                        <FileText className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="font-semibold text-slate-900 dark:text-white font-display block">{doc.title}</span>
                        <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-1 font-mono">
                          <span className="bg-slate-200 dark:bg-slate-800 px-1 rounded text-slate-500 font-bold uppercase">{doc.type}</span>
                          <span>{doc.size}</span>
                          <span>•</span>
                          <span>Phòng: <b>{doc.folder}</b></span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-slate-400 hidden sm:inline">Tải lên bởi: <b>{doc.author}</b></span>
                      <button
                        onClick={() => {
                          setUploadMsg(`Đang tải tệp "${doc.title}.${doc.type.toLowerCase()}" về máy trạm...`);
                          setTimeout(() => setUploadMsg(''), 4000);
                        }}
                        className="p-1.5 bg-slate-100 hover:bg-blue-600 hover:text-white dark:bg-slate-800 rounded-lg text-slate-500 transition-all cursor-pointer"
                        title="Tải tệp này"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>
                    </div>

                  </div>
                ))
              )}
            </div>

          </div>
        </div>

        {/* Right hand: Specifications and instructions warning */}
        <div className="lg:col-span-4">
          <div className="glass-card rounded-2xl p-5 space-y-4">
            <h3 className="text-sm font-bold font-display text-slate-800 dark:text-white uppercase tracking-wider flex items-center gap-2">
              <HardDrive className="w-4 h-4 text-blue-500" />
              <span>Dung Lượng Lưu Trữ</span>
            </h3>

            <div className="space-y-2">
              <div className="h-2 bg-slate-100 dark:bg-slate-850 rounded-full overflow-hidden">
                <div className="bg-blue-600 h-full w-[45%]" />
              </div>
              <div className="flex justify-between text-[11px] text-slate-400">
                <span>Đã dùng: 21.6 MB / 50 MB</span>
                <span>43.2%</span>
              </div>
            </div>

            <div className="p-3.5 bg-white/5 dark:bg-black/10 border border-white/5 rounded-xl space-y-2 text-xs font-light text-slate-600 dark:text-slate-350 leading-relaxed">
              <div className="flex items-center gap-1.5 font-bold font-display text-slate-800 text-[11px] uppercase text-blue-600">
                <Info className="w-4 h-4 shrink-0" />
                <span>Quy chuẩn tệp Tem Vivian</span>
              </div>
              <p>Mọi bản in Decal màng Vivian phải xuất file đúng định dạng vector hệ màu CMYK và tích hợp lớp phủ UV tự động rải sấy trước khi chuyển lệnh xuống máy xưởng.</p>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
}

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { User, UserRole, Department } from '../types';
import { DB } from '../lib/dataStore';
import { KeyRound, ShieldAlert, CheckCircle2, RefreshCw, LayoutDashboard, Sparkles } from 'lucide-react';
import { signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { auth } from '../lib/firebase';

interface LoginProps {
  onLoginSuccess: (user: User) => void;
}

export default function Login({ onLoginSuccess }: LoginProps) {
  const users = DB.getUsers();
  const [selectedDept, setSelectedDept] = useState<Department>(Department.ADMIN);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [forgotEmail, setForgotEmail] = useState('');
  const [showForgot, setShowForgot] = useState(false);

  const depts = Object.values(Department);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    
    // Check custom credentials for Sếp Trần Tuấn Anh
    if (email.trim().toLowerCase() === 'tuananhcdv') {
      if (password !== 'tdn@1234!') {
        setErrorMessage('Mật khẩu quản trị viên không chính xác!');
        return;
      }
      
      // Find or create Sếp Trần Tuấn Anh
      let foundUser = users.find(u => u.email === 'tuananhcdv' || u.role === UserRole.SUPER_ADMIN);
      if (!foundUser) {
        foundUser = {
          id: 'u1',
          email: 'tuananhcdv',
          name: 'Trần Tuấn Anh (Sếp Tín Dân)',
          role: UserRole.SUPER_ADMIN,
          department: Department.ADMIN,
          status: 'active',
          avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
          permissions: {
            canCreateTask: true,
            canEditTask: true,
            canDeleteTask: true,
            canBonusKPI: true,
            canExportReport: true,
            canUseAI: true
          }
        };
        DB.saveUsers([...users, foundUser]);
      } else {
        foundUser.email = 'tuananhcdv';
        foundUser.permissions = {
          canCreateTask: true,
          canEditTask: true,
          canDeleteTask: true,
          canBonusKPI: true,
          canExportReport: true,
          canUseAI: true
        };
        DB.saveUsers(users.map(u => u.id === foundUser!.id ? foundUser! : u));
      }

      DB.setCurrentUser(foundUser);
      setSuccessMsg(`Đăng nhập thành công! Kính chào Sếp Trần Tuấn Anh.`);
      setTimeout(() => {
        onLoginSuccess({
          ...foundUser!,
          department: selectedDept
        });
      }, 800);
      return;
    }

    // Find matching user
    const foundUser = users.find(u => u.email.trim().toLowerCase() === email.trim().toLowerCase());
    
    if (foundUser) {
      if (foundUser.status === 'locked') {
        setErrorMessage('Tài khoản này đã bị khóa bởi Admin. Vui lòng liên hệ hỗ trợ.');
        return;
      }
      
      // Successfully authenticated
      DB.setCurrentUser(foundUser);
      setSuccessMsg(`Đăng nhập thành công! Bộ phận: ${selectedDept}`);
      setTimeout(() => {
        onLoginSuccess({
          ...foundUser,
          department: selectedDept // Set requested department workspace
        });
      }, 800);
    } else {
      setErrorMessage('Không tìm thấy tài khoản với email này trong hệ thống.');
    }
  };

  const handleGoogleSignIn = async () => {
    setErrorMessage('');
    setSuccessMsg('');
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      const googleUser = result.user;
      
      const matchedUser = users.find(u => u.email.trim().toLowerCase() === googleUser.email?.trim().toLowerCase());
      
      let activeUser: User;
      if (matchedUser) {
        activeUser = {
          ...matchedUser,
          id: googleUser.uid
        };
      } else {
        activeUser = {
          id: googleUser.uid,
          email: googleUser.email || '',
          name: googleUser.displayName || 'Nhân sự Tín Dân',
          role: UserRole.EMPLOYEE,
          department: selectedDept,
          status: 'active',
          avatar: googleUser.photoURL || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face'
        };
        
        const existingUsers = DB.getUsers();
        if (!existingUsers.some(u => u.email.trim().toLowerCase() === activeUser.email.trim().toLowerCase())) {
          DB.saveUsers([...existingUsers, activeUser]);
        }
      }

      DB.setCurrentUser(activeUser);
      setSuccessMsg(`Đăng nhập Firebase thành công! Chào ${activeUser.name}`);
      setTimeout(() => {
        onLoginSuccess(activeUser);
      }, 800);
    } catch (error) {
      setErrorMessage('Kết nối Firebase thất bại: ' + (error instanceof Error ? error.message : String(error)));
    }
  };

  const handleQuickLogin = (user: User) => {
    setErrorMessage('');
    setEmail(user.email);
    setPassword('••••••••');
    setSelectedDept(user.department);
    
    DB.setCurrentUser(user);
    setSuccessMsg(`Đăng nhập siêu tốc: ${user.name}`);
    setTimeout(() => {
      onLoginSuccess(user);
    }, 800);
  };

  const handleForgotPassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotEmail) {
      setErrorMessage('Vui lòng nhập Email cần lấy lại mật khẩu');
      return;
    }
    setSuccessMsg(`Yêu cầu đặt lại mật khẩu đã gửi tới ${forgotEmail}!`);
    setShowForgot(false);
    setTimeout(() => setSuccessMsg(''), 4000);
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-slate-50 dark:bg-slate-950 font-sans transition-colors duration-300">
      
      {/* Decorative branding sidebar - Left Side */}
      <div className="w-full md:w-[45%] bg-gradient-to-br from-blue-700 via-blue-600 to-indigo-800 text-white flex flex-col justify-between p-8 md:p-12 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(255,255,255,0.15),transparent)] pointer-events-none" />
        <div className="absolute -bottom-24 -left-20 w-80 h-80 bg-blue-500/20 rounded-full blur-2xl glow-animation" />
        
        {/* Top Header Logo Banner */}
        <div className="flex items-center gap-3 relative z-10">
          <div className="bg-white p-1.5 rounded-xl shadow-lg flex items-center justify-center">
            <img 
              src="https://temvivian.vn/wp-content/uploads/2024/11/logo-tin-dan-tdn.png" 
              alt="Logo Tín Dân" 
              className="h-10 w-auto object-contain"
              onError={(e) => {
                // Return a beautiful fallback if broken image
                e.currentTarget.src = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=80&auto=format&fit=crop&q=60";
              }}
            />
          </div>
          <div>
            <span className="font-display font-bold tracking-tight text-xl block">TÍN DÂN CRM</span>
            <span className="text-xs text-blue-200 block tracking-wider font-mono">WORKSPACE OS v1.0</span>
          </div>
        </div>

        {/* Hero Slogan */}
        <div className="my-12 md:my-0 select-none relative z-10">
          <div className="inline-flex items-center gap-1.5 bg-blue-500/20 text-blue-200 text-xs px-2.5 py-1 rounded-full mb-4">
            <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
            <span>Hệ thống tích hợp Trí tuệ nhân tạo (AI)</span>
          </div>
          <h1 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold leading-tight mb-4 tracking-tight">
            Quản trị Vận hành <br />
            & Tối ưu Doanh thu
          </h1>
          <p className="text-blue-100/90 text-sm md:text-base leading-relaxed max-w-sm font-light">
            Nhận diện lỗi sản xuất xưởng in Tem Vivian, tự động hóa phân công công việc & theo sát năng lượng KPI từng vị trí bằng bộ công cụ AI tối tân.
          </p>
        </div>

        {/* Footer info */}
        <div className="text-xs text-blue-200 border-t border-blue-500/30 pt-6 relative z-10 font-mono">
          © 2026 Tín Dân Company. All rights reserved.
        </div>
      </div>

      {/* Main Login Form - Right Side */}
      <div className="flex-1 flex items-center justify-center p-6 md:p-12 relative">
        <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xl rounded-2xl p-6 md:p-8 relative">
          
          <div className="mb-6 text-center md:text-left">
            <h2 className="text-2xl font-bold text-slate-800 dark:text-white font-display">Đăng nhập tài khoản</h2>
            <p className="text-sm text-slate-500 dark:text-gray-400 mt-1">Chọn phân vùng phòng ban để tải không gian làm việc</p>
          </div>

          {/* Feedback alerts */}
          {errorMessage && (
            <div className="mb-4 p-3 bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900 text-xs text-red-600 dark:text-red-400 rounded-lg flex items-start gap-2.5">
              <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}
          {successMsg && (
            <div className="mb-4 p-3 bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900 text-xs text-emerald-600 dark:text-emerald-400 rounded-lg flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-500" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* Department Selection Slots */}
          <div className="mb-5">
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-2 uppercase tracking-wide">
              Môi trường Phòng ban
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-1.5">
              {depts.map((dept) => (
                <button
                  key={dept}
                  type="button"
                  onClick={() => setSelectedDept(dept)}
                  className={`py-1.5 px-2 text-xs rounded-lg border text-center font-medium font-display transition-all ${
                    selectedDept === dept
                      ? 'bg-blue-600 text-white border-blue-600 font-semibold shadow-md shadow-blue-500/10'
                      : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {dept}
                </button>
              ))}
            </div>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1.5">
                Email Đăng nhập
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="vd: tindancompany22@gmail.com"
                className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-white border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="relative">
              <div className="flex justify-between items-center mb-1.5">
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400">
                  Mật khẩu
                </label>
                <button
                  type="button"
                  onClick={() => setShowForgot(!showForgot)}
                  className="text-xs text-blue-600 dark:text-blue-400 hover:underline"
                >
                  Quên mật khẩu?
                </button>
              </div>

              <input
                type="password"
                required={!showForgot}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Nhập mật khẩu"
                className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-white border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* Forgot password nested pane */}
            {showForgot && (
              <div className="p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg space-y-2">
                <p className="text-xs text-slate-500 dark:text-slate-400">Nhập email phục hồi mật khẩu hệ thống</p>
                <div className="flex gap-2">
                  <input
                    type="email"
                    value={forgotEmail}
                    onChange={(e) => setForgotEmail(e.target.value)}
                    placeholder="email@tindan.vn"
                    className="flex-1 px-2.5 py-1 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded"
                  />
                  <button
                    type="button"
                    onClick={handleForgotPassword}
                    className="bg-blue-600 text-white px-3 py-1 text-xs font-medium rounded hover:bg-blue-700"
                  >
                    Gửi
                  </button>
                </div>
              </div>
            )}

            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="w-3.5 h-3.5 accent-blue-600 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                />
                Ghi nhớ đăng nhập
              </label>
            </div>

            <button
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg flex items-center justify-center gap-2 text-sm transition-all shadow-md shadow-blue-600/15"
            >
              <KeyRound className="w-4 h-4" />
              <span>Vào không gian làm việc</span>
            </button>

            <div className="relative flex items-center justify-center my-4">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-200 dark:border-slate-800"></div>
              </div>
              <span className="relative px-3 bg-white dark:bg-slate-900 text-xs text-slate-400 dark:text-slate-500 font-medium">Hoặc kết nối Firebase</span>
            </div>

            <button
              type="button"
              onClick={handleGoogleSignIn}
              className="w-full flex items-center justify-center gap-2 px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700 hover:text-blue-600 dark:hover:text-blue-400 transition-all shadow-sm"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path fill="#EA4335" d="M12 5.04c1.62 0 3.08.56 4.22 1.65l3.15-3.15C17.45 1.74 14.93 1 12 1 7.28 1 3.25 3.73 1.35 7.72l3.65 2.83C5.9 7.42 8.69 5.04 12 5.04z" />
                <path fill="#4285F4" d="M23.49 12.27c0-.81-.07-1.59-.2-2.36H12v4.51h6.43c-.28 1.44-1.1 2.66-2.33 3.48l3.61 2.8c2.11-1.95 3.52-4.8 3.52-8.43z" />
                <path fill="#FBBC05" d="M5 14.54c-.25-.74-.39-1.53-.39-2.36s.14-1.62.39-2.36L1.35 7.72C.49 9.54 0 11.66 0 13.91c0 2.25.49 4.37 1.35 6.19l3.65-2.83c-.25-.74-.39-1.53-.39-2.36z" />
                <path fill="#34A853" d="M12 23c3.24 0 5.97-1.07 7.96-2.91l-3.61-2.8c-1.1.74-2.5 1.18-4.35 1.18-3.31 0-6.1-2.38-7.1-5.51L1.25 15.8C3.15 19.78 7.18 23 12 23z" />
              </svg>
              <span>Đăng nhập với Google</span>
            </button>
          </form>

          {/* Quick Demo Accounts Filling Panel */}
          <div className="mt-6 pt-5 border-t border-slate-200/60 dark:border-slate-800">
            <span className="block text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-2.5">
              Đăng nhập thần tốc bằng tài khoản Demo:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {users.slice(0, 4).map((user) => (
                <button
                  key={user.id}
                  type="button"
                  onClick={() => handleQuickLogin(user)}
                  className="px-2.5 py-1 text-[11px] text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-blue-50 dark:hover:bg-blue-900 hover:text-blue-600 dark:hover:text-blue-300 font-medium rounded-full border border-slate-200/50 dark:border-slate-700 flex items-center gap-1 transition-all"
                >
                  <span>{user.name.split(' ')[2] || user.name.split(' ')[0]}</span>
                  <span className="text-[9px] px-1 bg-slate-200 dark:bg-slate-700 rounded text-slate-500 dark:text-slate-400">{user.role}</span>
                </button>
              ))}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}

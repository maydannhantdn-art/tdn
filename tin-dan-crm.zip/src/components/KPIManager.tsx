/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState } from 'react';
import { User, KPIs } from '../types';
import { DB } from '../lib/dataStore';
import { Award, UserCheck2, TrendingUp, AlertTriangle, CheckCircle, Star, PlusCircle, HelpCircle, FileSpreadsheet, Shield } from 'lucide-react';
import * as XLSX from 'xlsx';

interface KPIManagerProps {
  currentUser: User;
  kpis: KPIs[];
  setKpis: (kpis: KPIs[]) => void;
  onAddNotification: (title: string, content: string, type: string) => void;
}

export default function KPIManager({ currentUser, kpis, setKpis, onAddNotification }: KPIManagerProps) {
  const [awardScore, setAwardScore] = useState<number>(10);
  const [awardType, setAwardType] = useState<'plus' | 'minus'>('plus');
  const [selectedKpiId, setSelectedKpiId] = useState<string | null>(null);
  const [bonusComment, setBonusComment] = useState('');

  const isAdmin = currentUser.role === 'Super Admin' || currentUser.role === 'Admin';

  const handleExportExcelAll = () => {
    try {
      const wb = XLSX.utils.book_new();
      
      // 1. DATA FOR MAIN SHEET: "Tổng Hợp KPI"
      const mainData = kpis.map((k, index) => {
        const ratio = Math.round((k.completedTasks / (k.totalTasks || 1)) * 100);
        return {
          "STT": index + 1,
          "Họ và Tên Nhân Sự": k.employeeName,
          "Bộ Phận Công Tác": "Phòng " + k.department,
          "Tháng Đánh Giá": k.month || "Tháng 06/2026",
          "Tổng Số Nhiệm Vụ": k.totalTasks,
          "Số Việc Đã Xong": k.completedTasks,
          "Số Việc Trễ Hạn": k.overdueTasks,
          "Tỷ Lệ Hoàn Thành (%)": ratio + "%",
          "Cấp Bậc Xếp Hạng Stars": Math.max(1, Math.min(5, Math.round((ratio / 100) * 5))) + " Sao",
          "Điểm KPI Tích Lũy (đ)": k.kpiScore,
          "Nhật Ký Thưởng Phạt / Nhận Xét": k.notes || "Hoạt động công suất ổn định"
        };
      });

      const wsMain = XLSX.utils.json_to_sheet(mainData);
      
      // Style column widths for readability 
      wsMain['!cols'] = [
        { wch: 6 },   // STT
        { wch: 22 },  // Họ và Tên
        { wch: 18 },  // Bộ Phận
        { wch: 15 },  // Tháng
        { wch: 16 },  // Tổng Số Nhiệm Vụ
        { wch: 15 },  // Đã xong
        { wch: 15 },  // Trễ hạn
        { wch: 20 },  // Tỷ Lệ
        { wch: 22 },  // Sao
        { wch: 20 },  // Điểm KPI
        { wch: 38 }   // Nhận xét
      ];

      XLSX.utils.book_append_sheet(wb, wsMain, "Tổng Hợp KPI Chung");

      // 2. CREATE SEPARATE SHEET FOR EACH EMPLOYEE
      // Get all tasks to list detail work history for each sheet
      const allTasks = DB.getTasks();

      kpis.forEach(k => {
        // Filter tasks explicitly assigned to this personnel
        const personTasks = allTasks.filter(t => {
          const namePart = k.employeeName.toLowerCase().split(' ')[0];
          return t.assignee.toLowerCase().includes(namePart);
        });

        // Top Header style in user sheet
        const empSheetData = [
          { "A": "BÁO CÁO HIỆU SUẤT LAO ĐỘNG CÁ NHÂN - SẾP TUẤN ANH PHÊ DUYỆT" },
          { "A": "Họ và Tên: " + k.employeeName },
          { "A": "Bộ Phận công tác: Phòng " + k.department },
          { "A": "Tháng Đánh Giá: " + (k.month || "Tháng 06/2026") },
          { "A": "Tổng điểm tích lũy KPI: " + k.kpiScore + " điểm" },
          { "A": "Nhận xét của ban giám đốc: " + (k.notes || "Cán bộ nỗ lực hoàn thành công việc xuất sắc.") },
          { "A": "" }, // Blank row
          { "A": "DANH SÁCH CHI TIẾT CÁC CÔNG VIỆC THỰC THI TRONG THÁNG" },
        ];

        const wsEmp = XLSX.utils.json_to_sheet(empSheetData, { skipHeader: true });

        // Add a detailed table for their roles
        const empTable = personTasks.map((t, idx) => ({
          "STT": idx + 1,
          "Tiêu Đề Công Việc": t.title,
          "Mô Tả Nhiệm Vụ": t.description,
          "Độ Khẩn Cấp": t.priority,
          "Trạng Thử": t.status === "Done" ? "ĐÃ HOÀN THÀNH" : t.status === "In Progress" ? "ĐANG THỰC HIỆN" : "CHƯA KHỞI CHẠY",
          "Hạn Định Chót": t.deadline,
          "Điểm Thưởng Phân Bổ": t.kpiScore + "đ",
          "Dự Án Trực Thuộc": t.projectName || "Dự Án Chung"
        }));

        if (empTable.length > 0) {
          XLSX.utils.sheet_add_json(wsEmp, empTable, { origin: "A10" });
        } else {
          XLSX.utils.sheet_add_aoa(wsEmp, [["Không ghi nhận đầu việc phát sinh trong kỳ đánh giá."]], { origin: "A10" });
        }

        wsEmp['!cols'] = [
          { wch: 6 },   // STT
          { wch: 30 },  // Tiêu Đề
          { wch: 45 },  // Mô Tả
          { wch: 12 },  // Độ khẩn
          { wch: 16 },  // Trạng thái
          { wch: 15 },  // Hạn chót
          { wch: 15 },  // Điểm thưởng
          { wch: 22 }   // Dự án
        ];

        // Format sheet naming (Limit to max 31 characters in sheet names)
        const sheetName = k.employeeName.substring(0, 31);
        XLSX.utils.book_append_sheet(wb, wsEmp, sheetName);
      });

      // Write File to Browser download
      XLSX.writeFile(wb, "Report_Tong_Hop_KPI_Marketing_7_Nhan_Su.xlsx");
      
      onAddNotification(
        "Xuất Báo Cáo Thành Công",
        "Đã kết xuất Report_Tong_Hop_KPI_Marketing_7_Nhan_Su.xlsx đa sheet cho từng nhân sự tải về máy.",
        "system"
      );
    } catch (err) {
      console.error("Export error:", err);
      alert("Đã xảy ra sự cố trong quá trình kết xuất bảng tính!");
    }
  };

  const triggerAddBonus = (kpiId: string) => {
    if (!isAdmin) {
      alert("Bạn không có đặc quyền điều chỉnh quỹ điểm KPI!");
      return;
    }
    const updated = kpis.map(k => {
      if (k.id === kpiId) {
        const factor = awardType === 'plus' ? 1 : -1;
        const delta = awardScore * factor;
        const nextScore = Math.max(0, k.kpiScore + delta);
        
        const actionWord = awardType === 'plus' ? 'Cộng thưởng' : 'Khấu trừ phạt';
        const signSymbol = awardType === 'plus' ? '+' : '-';
        const note = `Được ${actionWord} ${signSymbol}${awardScore}đ bởi ${currentUser.name}. Lý do: ${bonusComment || 'Điều chỉnh năng lực hoạt động.'}`;
        
        onAddNotification(
          `${actionWord} điểm KPI`,
          `Nhân sự ${k.employeeName} đã bị tác động ${signSymbol}${awardScore}đ KPI. Lý do: ${bonusComment || 'Xét duyệt công tâm.'}`,
          'system'
        );

        return { 
          ...k, 
          kpiScore: nextScore,
          notes: note
        };
      }
      return k;
    });

    setKpis(updated);
    DB.saveKPIs(updated);
    
    // Clear inputs
    setSelectedKpiId(null);
    setBonusComment('');
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto p-4 md:p-6 lg:p-8 font-sans">
      
      {/* Title */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white font-display">
            Chỉ số Hiệu suất & Xếp hạng KPI
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Quản lý minh bạch hiệu lực lao động của các phòng ban Tín Dân Company. Ghi nhận tức thời và khích lệ tự động.
          </p>
        </div>

        {currentUser.permissions?.canExportReport !== false && (
          <button
            onClick={handleExportExcelAll}
            className="py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl flex items-center gap-2 transition-all outline-none cursor-pointer shadow-lg shadow-emerald-500/15"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Xuất Báo Cáo Excel Đa Sheet</span>
          </button>
        )}
      </div>

      {/* Corporate benchmark banners */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        <div className="bg-gradient-to-r from-emerald-500 to-emerald-600 text-white p-4 rounded-xl shadow-sm flex items-center justify-between">
          <div>
            <span className="text-[10px] text-emerald-100 uppercase tracking-widest font-bold">Hoàn thành nhiều nhất</span>
            <span className="text-lg font-bold block mt-1">Trần Minh Đức</span>
            <span className="text-[10px] text-emerald-100">Phòng Kỹ Thuật • Tỉ lệ 95%</span>
          </div>
          <Award className="w-8 h-8 opacity-80" />
        </div>

        <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-4 rounded-xl shadow-sm flex items-center justify-between">
          <div>
            <span className="text-[10px] text-blue-100 uppercase tracking-widest font-bold">Ngôi sao đang lên</span>
            <span className="text-lg font-bold block mt-1">Nguyễn Văn Nam</span>
            <span className="text-[10px] text-blue-100">Phòng Marketing • Tích lũy 145đ</span>
          </div>
          <TrendingUp className="w-8 h-8 opacity-80" />
        </div>

        <div className="bg-gradient-to-r from-purple-500 to-purple-600 text-white p-4 rounded-xl shadow-sm flex items-center justify-between">
          <div>
            <span className="text-[10px] text-purple-100 uppercase tracking-widest font-bold">Thưởng tổng kết năm</span>
            <span className="text-lg font-bold block mt-1">Công suất ổn định</span>
            <span className="text-[10px] text-purple-100">Trung bình đạt 4.2 sao</span>
          </div>
          <Star className="w-8 h-8 opacity-80 fill-purple-200" />
        </div>

      </div>

      {/* KPI Official Fair Regulation Board */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-slate-900/40 dark:to-indigo-950/20 border border-blue-100 dark:border-indigo-950/60 rounded-2xl p-5 space-y-4">
        <div className="flex items-center gap-2.5">
          <HelpCircle className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
          <h2 className="text-sm font-bold text-slate-900 dark:text-white font-display uppercase tracking-wider">
            QUY CHẾ CHẤM ĐIỂM KPI TÍN DÂN COMPANY – CÔNG TÂM & MINH BẠCH
          </h2>
        </div>
        <p className="text-xs text-slate-650 dark:text-slate-300 leading-relaxed max-w-4xl">
          Công thức tính toán KPI được chuẩn hóa tự động dựa trên số liệu thực tế tại xưởng in Tem Vivian và chiến dịch tăng trưởng phòng ban. Ban quản trị phê duyệt bảo đảm tính công khai, chính xác và đồng thuận 100%.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-1">
          <div className="bg-white/80 dark:bg-black/40 p-3.5 rounded-xl border border-slate-150 dark:border-white/5 space-y-2">
            <h3 className="text-xs font-bold text-indigo-605 dark:text-indigo-400 flex items-center gap-1.5">
              <CheckCircle className="w-4 h-4 text-emerald-500" />
              <span>Công thức Điểm KPI</span>
            </h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed font-mono">
              KPI = (Sản lượng việc hoàn thành × 70%) + (Điểm điều chỉnh quản lý × 30%) - Điểm phạt trễ hạn.
            </p>
          </div>

          <div className="bg-white/80 dark:bg-black/40 p-3.5 rounded-xl border border-slate-150 dark:border-white/5 space-y-2">
            <h3 className="text-xs font-bold text-indigo-605 dark:text-indigo-400 flex items-center gap-1.5">
              <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
              <span>Tiêu chí Xếp hạng Sao</span>
            </h3>
            <ul className="text-[11px] text-slate-500 dark:text-slate-400 space-y-1">
              <li>• ⭐⭐⭐⭐⭐ <b>(Xuất sắc)</b>: Tỷ lệ hoàn thành &gt; 90%</li>
              <li>• ⭐⭐⭐⭐ <b>(Khá Giỏi)</b>: Tỷ lệ đạt từ 70% đến 89%</li>
              <li>• ⭐⭐⭐ <b>(Đạt Yêu Cầu)</b>: Tỷ lệ đạt từ 50% đến 69%</li>
            </ul>
          </div>

          <div className="bg-white/80 dark:bg-black/40 p-3.5 rounded-xl border border-slate-150 dark:border-white/5 space-y-2">
            <h3 className="text-xs font-bold text-indigo-605 dark:text-indigo-400 flex items-center gap-1.5">
              <Shield className="w-4 h-4 text-indigo-500" />
              <span>Thẩm Quyền Chênh Lệch</span>
            </h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
              <b>Chỉ Admin & Sếp Tuấn Anh</b> mới có đặc quyền ký phê duyệt cộng/trừ điểm KPI thưởng phạt trực tiếp để khích lệ cán bộ.
            </p>
          </div>
        </div>
      </div>

      {/* KPI Listing table card board */}
      <div className="glass-card rounded-2xl overflow-hidden text-xs">
        <div className="p-4 border-b border-white/5 dark:border-white/5 flex justify-between items-center bg-white/5 dark:bg-black/20">
          <span className="font-bold text-slate-800 dark:text-white uppercase tracking-wider">Danh sách xếp hạng phòng ban</span>
          <span className="text-[10px] text-slate-400">Tháng hiện tại: Tháng 06/2026</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-100/50 dark:bg-slate-900 text-slate-500 font-bold uppercase tracking-wider border-b border-slate-150 dark:border-slate-800">
                <th className="p-4">Nhân sự thực thi</th>
                <th className="p-4">Phòng ban</th>
                <th className="p-4 text-center">Hoàn thành</th>
                <th className="p-4 text-center">Trễ hạn</th>
                <th className="p-4">Xếp hạng Star</th>
                <th className="p-4">Nhật ký phần thưởng</th>
                <th className="p-4">Hiện tại KPI</th>
                <th className="p-4 text-center">Hành động</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-150 dark:divide-slate-800">
              {kpis.map((k) => {
                const ratio = Math.round((k.completedTasks / (k.totalTasks || 1)) * 100);
                const starRating = Math.max(1, Math.min(5, Math.round((ratio / 100) * 5)));

                return (
                  <tr key={k.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-850/30 text-slate-700 dark:text-slate-300">
                    <td className="p-4 font-semibold text-slate-900 dark:text-white">
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 font-bold text-[10px] flex items-center justify-center">
                          {k.employeeName.charAt(0)}
                        </div>
                        <span>{k.employeeName}</span>
                      </div>
                    </td>
                    <td className="p-4">{k.department}</td>
                    <td className="p-4 text-center">
                      <span className="font-bold font-mono text-slate-900 dark:text-white">{k.completedTasks}</span>
                      <span className="text-[10px] text-slate-400">/{k.totalTasks}</span>
                    </td>
                    <td className="p-4 text-center text-rose-500 font-bold font-mono">{k.overdueTasks}</td>
                    
                    {/* Stars render */}
                    <td className="p-4">
                      <div className="flex text-amber-500 gap-0.5">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star 
                            key={i} 
                            className={`w-3.5 h-3.5 ${i < starRating ? 'fill-yellow-400 text-yellow-400' : 'text-slate-200'}`} 
                          />
                        ))}
                      </div>
                    </td>

                    <td className="p-4 text-slate-400 italic max-w-xs truncate" title={k.notes}>
                      {k.notes || 'Công suất ổn định'}
                    </td>

                    <td className="p-4 text-emerald-600 font-bold font-mono text-xs">
                      {k.kpiScore}đ
                    </td>

                    <td className="p-4 text-center">
                      {isAdmin ? (
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedKpiId(k.id);
                            setAwardType('plus');
                          }}
                          className="px-2.5 py-1 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-600 hover:text-white border border-indigo-200 dark:border-indigo-900 rounded-lg text-[10px] font-bold uppercase transition-all cursor-pointer"
                        >
                          Cấu Hình KPI
                        </button>
                      ) : (
                        <span className="text-slate-400 text-[10px]">Chỉ Admin</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Bonus Award overlay pop up */}
      {selectedKpiId && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center p-4 z-50">
          <div className="glass-card w-full max-w-sm rounded-2xl overflow-hidden block shadow-2xl">
            <div className="p-4 border-b border-white/5 bg-white/5 dark:bg-black/20 font-bold text-xs">
              ⚡ Điều chỉnh KPI: {kpis.find(k => k.id === selectedKpiId)?.employeeName}
            </div>

            <div className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-550 dark:text-slate-400 mb-1.5 font-sans">
                  Phương thức tác động
                </label>
                <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 dark:bg-slate-900 rounded-lg">
                  <button
                    type="button"
                    onClick={() => setAwardType('plus')}
                    className={`py-1.5 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                      awardType === 'plus' 
                        ? 'bg-blue-600 text-white shadow-sm' 
                        : 'text-slate-500 hover:text-slate-700'
                    }`}
                  >
                    ➕ Cộng Thưởng
                  </button>
                  <button
                    type="button"
                    onClick={() => setAwardType('minus')}
                    className={`py-1.5 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                      awardType === 'minus' 
                        ? 'bg-rose-600 text-white shadow-sm' 
                        : 'text-slate-500 hover:text-slate-700'
                    }`}
                  >
                    ➖ Trừ Điểm Phạt
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-550 dark:text-slate-400 mb-1.5">
                  Giá trị điều chỉnh (Điểm KPI)
                </label>
                <select
                  value={awardScore}
                  onChange={(e) => setAwardScore(parseInt(e.target.value))}
                  className="w-full glass-dropdown text-xs py-2 px-3 rounded-lg font-bold font-sans"
                >
                  <option value={5}>5 Điểm (Mức cơ bản / Hoàn tất việc phát sinh)</option>
                  <option value={10}>10 Điểm (Tăng ca tích cực / Xử lý trọn vẹn sự cố)</option>
                  <option value={20}>20 Điểm (Năng suất vượt trội / Kết quả đột phá)</option>
                  <option value={50}>50 Điểm (Ký hợp đồng lớn / Chiến dịch xuất sắc)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-550 dark:text-slate-400 mb-1.5">
                  Lý do thực tế & Ghi nhận hành vi
                </label>
                <input
                  type="text"
                  required
                  value={bonusComment}
                  onChange={(e) => setBonusComment(e.target.value)}
                  placeholder="Nhập lý do chi tiết..."
                  className="w-full glass-input rounded-lg text-xs py-2 px-3 focus:outline-none text-slate-850 dark:text-white"
                />
              </div>
            </div>

            <div className="p-3 border-t border-white/5 bg-white/5 dark:bg-black/20 flex justify-end gap-2 text-xs">
              <button
                type="button"
                onClick={() => setSelectedKpiId(null)}
                className="px-3 py-1.5 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-350 rounded-lg cursor-pointer"
              >
                Hủy bỏ
              </button>
              <button
                type="button"
                onClick={() => triggerAddBonus(selectedKpiId)}
                className={`px-4 py-1.5 text-white rounded-lg font-bold cursor-pointer transition-all ${
                  awardType === 'plus' ? 'bg-blue-600 hover:bg-blue-700' : 'bg-rose-600 hover:bg-rose-700'
                }`}
              >
                {awardType === 'plus' ? 'Phê duyệt Cộng' : 'Quyết định Trừ'}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}

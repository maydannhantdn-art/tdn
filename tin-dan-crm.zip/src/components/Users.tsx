/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { User, UserRole, Department } from '../types';
import { DB } from '../lib/dataStore';
import { 
  UserPlus, 
  Users as UsersIcon, 
  Shield, 
  Lock, 
  Unlock, 
  Check, 
  X, 
  Search, 
  UserX, 
  Edit3, 
  Save,
  Trash2
} from 'lucide-react';

interface UsersProps {
  currentUser: User;
  onAddNotification: (title: string, content: string, type: string) => void;
}

export default function Users({ currentUser, onAddNotification }: UsersProps) {
  const [users, setUsers] = useState<User[]>(DB.getUsers());
  const [searchQuery, setSearchQuery] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);

  // Form states for new/editing user
  const [formName, setFormName] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formRole, setFormRole] = useState<UserRole>(UserRole.EMPLOYEE);
  const [formDept, setFormDept] = useState<Department>(Department.MARKETING);
  const [formPosition, setFormPosition] = useState('');
  const [formPassword, setFormPassword] = useState('');
  const [formPermissions, setFormPermissions] = useState({
    canCreateTask: true,
    canEditTask: true,
    canDeleteTask: false,
    canBonusKPI: false,
    canExportReport: false
  });

  const depts = Object.values(Department);
  const roles = Object.values(UserRole);

  const filteredUsers = users.filter(u => {
    const q = searchQuery.toLowerCase();
    return u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q) || u.role.toLowerCase().includes(q) || u.department.toLowerCase().includes(q);
  });

  const openCreateModal = () => {
    setFormName('');
    setFormEmail('');
    setFormRole(UserRole.EMPLOYEE);
    setFormDept(Department.MARKETING);
    setFormPosition('');
    setFormPassword('');
    setFormPermissions({
      canCreateTask: true,
      canEditTask: true,
      canDeleteTask: false,
      canBonusKPI: false,
      canExportReport: true
    });
    setEditingUser(null);
    setShowCreateModal(true);
  };

  const openEditModal = (user: User) => {
    setFormName(user.name);
    setFormEmail(user.email);
    setFormRole(user.role);
    setFormDept(user.department);
    setFormPosition(user.position || '');
    setFormPassword(user.password || '');
    setFormPermissions(user.permissions || {
      canCreateTask: user.role !== UserRole.EMPLOYEE,
      canEditTask: user.role !== UserRole.EMPLOYEE,
      canDeleteTask: user.role === UserRole.SUPER_ADMIN,
      canBonusKPI: user.role !== UserRole.EMPLOYEE,
      canExportReport: user.role !== UserRole.EMPLOYEE
    });
    setEditingUser(user);
    setShowCreateModal(true);
  };

  const handleSaveUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName || !formEmail) return;

    if (editingUser) {
      // Edit mode
      const updated = users.map(u => {
        if (u.id === editingUser.id) {
          return {
            ...u,
            name: formName,
            email: formEmail,
            role: formRole,
            department: formDept,
            position: formPosition,
            password: formPassword,
            permissions: formPermissions
          };
        }
        return u;
      });
      setUsers(updated);
      DB.saveUsers(updated);
      onAddNotification(
        'Cập nhật thành viên',
        `Đã tinh chỉnh thông tin & phân quyền cho cán bộ ${formName} thành công.`,
        'system'
      );
    } else {
      // Create mode
      const newUser: User = {
        id: 'u_' + Date.now(),
        email: formEmail,
        name: formName,
        role: formRole,
        department: formDept,
        position: formPosition,
        password: formPassword,
        status: 'active',
        avatar: `https://images.unsplash.com/photo-${1500000000000 + Math.floor(Math.random() * 99999)}?w=150&h=150&fit=crop&crop=face`,
        permissions: formPermissions
      };
      const updated = [...users, newUser];
      setUsers(updated);
      DB.saveUsers(updated);
      onAddNotification(
        'Thành viên mới',
        `Cán bộ ${formName} vừa được khởi tạo trực thuộc phòng ${formDept} với phân cụm quyền năng mới.`,
        'system'
      );
    }

    setShowCreateModal(false);
  };

  const toggleUserStatus = (userId: string) => {
    const updated = users.map(u => {
      if (u.id === userId) {
        const nextStatus = u.status === 'active' ? 'locked' : 'active';
        onAddNotification(
          u.status === 'active' ? 'Khóa tài khoản' : 'Mở khóa tài khoản',
          `Hệ thống đã ${nextStatus === 'locked' ? 'khóa' : 'mở khóa'} trạng thái hoạt động của ${u.name}.`,
          'system'
        );
        return { ...u, status: nextStatus as 'active' | 'locked' };
      }
      return u;
    });
    setUsers(updated);
    DB.saveUsers(updated);
  };

  const handleDeleteUser = (userId: string) => {
    if (userId === currentUser.id) {
      alert("Không thể xóa chính tài khoản bạn đang sử dụng!");
      return;
    }
    const filtered = users.filter(u => u.id !== userId);
    setUsers(filtered);
    DB.saveUsers(filtered);
    onAddNotification(
      'Hủy tư cách thành viên',
      `Đã xóa hồ sơ nhân sự ra khỏi trục điều hành CRM Tín Dân.`,
      'system'
    );
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto p-4 md:p-6 lg:p-8 font-sans">
      
      {/* Title & Toolbar */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white font-display">
            Quản lý Nhân Sự & Phân Quyền
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Thiết đặt tài khoản, cấu hình chi tiết phân quyền hoạt động cho từng nhân sự xưởng in Tem Vivian.
          </p>
        </div>

        <button
          onClick={openCreateModal}
          className="py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-all outline-none cursor-pointer"
        >
          <UserPlus className="w-4 h-4" />
          <span>Thêm Nhân Viên Mới</span>
        </button>
      </div>

      {/* Search and Filters */}
      <div className="glass-card p-4 rounded-xl shadow-sm flex items-center justify-between gap-4">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Tìm kiếm theo tên, email, vai trò, phòng ban..."
            className="w-full glass-input rounded-lg text-xs py-2 pl-9 pr-4 focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-800 dark:text-white"
          />
        </div>
      </div>

      {/* Users Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredUsers.map((user) => {
          const uPerms = user.permissions || {
            canCreateTask: user.role !== UserRole.EMPLOYEE,
            canEditTask: user.role !== UserRole.EMPLOYEE,
            canDeleteTask: user.role === UserRole.SUPER_ADMIN,
            canBonusKPI: user.role !== UserRole.EMPLOYEE,
            canExportReport: user.role !== UserRole.EMPLOYEE
          };

          return (
            <div 
              key={user.id} 
              className={`glass-card p-5 rounded-2xl border transition-all flex flex-col justify-between space-y-4 ${
                user.status === 'locked' ? 'opacity-65 border-dashed border-red-300' : 'hover:border-blue-500/30'
              }`}
            >
              {/* Profile Card Header */}
              <div className="flex justify-between items-start">
                <div className="flex gap-3">
                  <img 
                    src={user.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120'} 
                    alt={user.name} 
                    className="w-12 h-12 rounded-full border border-slate-200 object-cover shrink-0"
                  />
                  <div>
                    <h3 className="text-xs font-bold text-slate-900 dark:text-white font-display flex items-center gap-1">
                      {user.name}
                      {user.status === 'locked' && (
                        <span className="text-[9px] px-1.5 py-0.5 bg-red-100 text-red-600 rounded">KHÓA</span>
                      )}
                    </h3>
                    <p className="text-[10px] text-slate-400 mt-0.5 truncate max-w-[170px]">{user.email}</p>
                    {user.position && (
                      <p className="text-[10px] text-indigo-600 dark:text-indigo-400 font-semibold font-display tracking-wide uppercase mt-1">
                        💼 {user.position}
                      </p>
                    )}
                    {user.password && (
                      <p className="text-[8.5px] text-slate-400 font-mono mt-0.5">🔑 Bảo mật mật khẩu</p>
                    )}
                    <div className="flex items-center gap-1.5 mt-1">
                      <span className="text-[9px] font-bold px-2 py-0.5 bg-blue-50 dark:bg-blue-900/40 text-blue-600 dark:text-blue-300 rounded font-mono uppercase">
                        {user.department}
                      </span>
                      <span className="text-[9px] font-bold px-2 py-0.5 bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 rounded uppercase">
                        {user.role}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={() => openEditModal(user)}
                    className="p-1 text-slate-400 hover:text-blue-600 transition-colors"
                    title="Cấu hình quyền"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => toggleUserStatus(user.id)}
                    className={`p-1 transition-colors ${
                      user.status === 'active' ? 'text-emerald-500 hover:text-red-500' : 'text-red-500 hover:text-emerald-500'
                    }`}
                    title={user.status === 'active' ? 'Khóa nhân sự' : 'Mở khóa nhân sự'}
                  >
                    {user.status === 'active' ? <Unlock className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
                  </button>

                  {user.id !== currentUser.id && (
                    <button
                      onClick={() => handleDeleteUser(user.id)}
                      className="p-1 text-slate-400 hover:text-rose-500 transition-colors"
                      title="Xóa hồ sơ"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

              {/* Detail Permissions */}
              <div className="border-t border-slate-100 dark:border-slate-800 pt-3.5 space-y-2.5">
                <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-widest">Quyền hạn hoạt động:</span>
                
                <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-650 dark:text-slate-300 font-light">
                  <div className="flex items-center gap-1.5">
                    {uPerms.canCreateTask ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <X className="w-3.5 h-3.5 text-slate-300" />}
                    <span>Tạo nhiệm vụ</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {uPerms.canEditTask ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <X className="w-3.5 h-3.5 text-slate-300" />}
                    <span>Chỉnh sửa việc</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {uPerms.canDeleteTask ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <X className="w-3.5 h-3.5 text-slate-300" />}
                    <span>Xóa việc</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {uPerms.canBonusKPI ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <X className="w-3.5 h-3.5 text-slate-300" />}
                    <span>Thưởng KPI</span>
                  </div>
                  <div className="flex items-center gap-1.5 col-span-2">
                    {uPerms.canExportReport ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <X className="w-3.5 h-3.5 text-slate-300" />}
                    <span>Xuất báo cáo bản tính</span>
                  </div>
                </div>
              </div>

            </div>
          );
        })}
      </div>

      {/* CREATE / EDIT USER MODAL OVERLAY */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <form onSubmit={handleSaveUser} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 w-full max-w-md rounded-2xl shadow-2xl overflow-hidden block">
            
            <div className="bg-slate-50 dark:bg-slate-850 p-5 border-b border-slate-150 dark:border-slate-800 flex justify-between items-center">
              <span className="font-bold text-sm text-slate-800 dark:text-white font-display">
                {editingUser ? 'Hiệu chỉnh nhân viên & phân quyền' : 'Khai sinh hồ sơ nhân sự mới'}
              </span>
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="text-slate-400 hover:text-slate-700"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              
              <div>
                <label className="block font-semibold text-slate-600 dark:text-slate-400 mb-1.5">Họ và Tên</label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="Vd: Nguyễn Văn Nam"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-250 dark:border-slate-700 rounded-lg py-2 px-3 focus:ring-1 focus:ring-blue-500 text-slate-800 dark:text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-600 dark:text-slate-400 mb-1.5">Email hoặc định danh đăng nhập</label>
                <input
                  type="text"
                  required
                  value={formEmail}
                  onChange={(e) => setFormEmail(e.target.value)}
                  placeholder="Vd: tuananhcdv hoặc nam.nguyen@tindan.vn"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-250 dark:border-slate-700 rounded-lg py-2 px-3 focus:ring-1 focus:ring-blue-500 text-slate-800 dark:text-white focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-slate-600 dark:text-slate-400 mb-1.5">Chức danh / Chức vụ</label>
                  <input
                    type="text"
                    value={formPosition}
                    onChange={(e) => setFormPosition(e.target.value)}
                    placeholder="Vd: Kỹ Sư In Decal UV, Sales Lead"
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-250 dark:border-slate-700 rounded-lg py-2 px-3 focus:ring-1 focus:ring-blue-500 text-slate-800 dark:text-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-600 dark:text-slate-400 mb-1.5">Mật khẩu tài khoản</label>
                  <input
                    type="text"
                    value={formPassword}
                    onChange={(e) => setFormPassword(e.target.value)}
                    placeholder="Vd: tdn@123..."
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-250 dark:border-slate-700 rounded-lg py-2 px-3 focus:ring-1 focus:ring-blue-500 text-slate-800 dark:text-white focus:outline-none font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-slate-600 dark:text-slate-400 mb-1.5">Phân cấp Chức vụ</label>
                  <select
                    value={formRole}
                    onChange={(e) => setFormRole(e.target.value as UserRole)}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-250 dark:border-slate-700 rounded-lg py-2 px-3 text-slate-800 dark:text-white focus:outline-none"
                  >
                    {roles.map(r => (
                      <option key={r} value={r}>{r}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-600 dark:text-slate-400 mb-1.5">Phòng ban</label>
                  <select
                    value={formDept}
                    onChange={(e) => setFormDept(e.target.value as Department)}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-250 dark:border-slate-700 rounded-lg py-2 px-3 text-slate-800 dark:text-white focus:outline-none"
                  >
                    {depts.map(d => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Detailed checkboxes for custom user permissions */}
              <div className="border-t border-slate-100 dark:border-slate-800 pt-4 space-y-3">
                <span className="font-bold text-slate-600 dark:text-slate-400 uppercase tracking-widest block text-[10px]">
                  Cấp phát chi tiết quyền hoạt động:
                </span>

                <div className="space-y-2 text-slate-755 dark:text-slate-300">
                  <label className="flex items-center gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formPermissions.canCreateTask}
                      onChange={(e) => setFormPermissions({...formPermissions, canCreateTask: e.target.checked})}
                      className="w-4 h-4 accent-blue-600"
                    />
                    <span>Quyền tạo đầu việc của phòng ban</span>
                  </label>

                  <label className="flex items-center gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formPermissions.canEditTask}
                      onChange={(e) => setFormPermissions({...formPermissions, canEditTask: e.target.checked})}
                      className="w-4 h-4 accent-blue-600"
                    />
                    <span>Quyền chỉnh sửa thông tin đầu việc</span>
                  </label>

                  <label className="flex items-center gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formPermissions.canDeleteTask}
                      onChange={(e) => setFormPermissions({...formPermissions, canDeleteTask: e.target.checked})}
                      className="w-4 h-4 accent-blue-600"
                    />
                    <span>Quyền xóa bỏ đầu việc vĩnh viễn (Chỉ Admin)</span>
                  </label>

                  <label className="flex items-center gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formPermissions.canBonusKPI}
                      onChange={(e) => setFormPermissions({...formPermissions, canBonusKPI: e.target.checked})}
                      className="w-4 h-4 accent-blue-600"
                    />
                    <span>Quyền cộng/trừ điểm thưởng KPI nhân sự</span>
                  </label>

                  <label className="flex items-center gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formPermissions.canExportReport}
                      onChange={(e) => setFormPermissions({...formPermissions, canExportReport: e.target.checked})}
                      className="w-4 h-4 accent-blue-600"
                    />
                    <span>Quyền phê duyệt xuất và tải báo cáo đa Sheet</span>
                  </label>
                </div>
              </div>

            </div>

            <div className="p-4 bg-slate-50 dark:bg-slate-850 border-t border-slate-150 dark:border-slate-800 flex justify-end gap-2 text-xs">
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="px-4 py-2 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-350 font-semibold rounded-lg"
              >
                Hủy bỏ
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-750"
              >
                {editingUser ? 'Lưu Thiết Đặt' : 'Khởi Tạo Nhân Viên'}
              </button>
            </div>

          </form>
        </div>
      )}

    </div>
  );
}

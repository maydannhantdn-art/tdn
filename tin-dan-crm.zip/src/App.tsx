/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { User, Task, Project, KPIs, Notification, TaskComment, ThemeMode } from './types';
import { DB } from './lib/dataStore';
import { onAuthStateChanged } from 'firebase/auth';
import { auth } from './lib/firebase';
import { seedFirestoreIfEmpty, subscribeToFirebaseUpdates } from './lib/firebaseSync';

// Load child panels modularly
import Login from './components/Login';
import Navigation from './components/Navigation';
import Dashboard from './components/Dashboard';
import Tasks from './components/Tasks';
import ProjectManager from './components/ProjectManager';
import AIImport from './components/AIImport';
import AIReports from './components/AIReports';
import KPIManager from './components/KPIManager';
import AIAssistant from './components/AIAssistant';
import FileCenter from './components/FileCenter';
import Settings from './components/Settings';
import AIQuickActionBar from './components/AIQuickActionBar';
import Users from './components/Users';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [themeMode, setThemeMode] = useState<ThemeMode>(ThemeMode.LIGHT);
  const [currentTime, setCurrentTime] = useState<Date>(new Date());

  // Real-time work update interval
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // States mirroring our local dataStore tables
  const [tasks, setTasks] = useState<Task[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [kpis, setKpis] = useState<KPIs[]>([]);
  const [comments, setComments] = useState<TaskComment[]>([]);

  // On mount: load initial state bags and sync with Firebase
  useEffect(() => {
    setTasks(DB.getTasks());
    setProjects(DB.getProjects());
    setNotifications(DB.getNotifications());
    setKpis(DB.getKPIs());
    setComments(DB.getComments());

    // Auto authenticate previous session if remembers
    const savedUser = DB.getCurrentUser();
    if (savedUser) {
      setCurrentUser(savedUser);
    }

    // Firebase Auth and real-time syncing setup
    let unsubscribeUpdates: (() => void) | null = null;
    const unsubscribeAuth = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        console.log("Firebase Auth connected:", firebaseUser.email);
        await seedFirestoreIfEmpty();

        if (unsubscribeUpdates) unsubscribeUpdates();
        unsubscribeUpdates = subscribeToFirebaseUpdates({
          onTasksChange: setTasks,
          onProjectsChange: setProjects,
          onCommentsChange: setComments,
          onKPIsChange: setKpis,
          onNotificationsChange: setNotifications,
        });
      } else {
        if (unsubscribeUpdates) {
          unsubscribeUpdates();
          unsubscribeUpdates = null;
        }
      }
    });

    return () => {
      unsubscribeAuth();
      if (unsubscribeUpdates) unsubscribeUpdates();
    };
  }, []);

  // Theme support toggle observer
  useEffect(() => {
    if (themeMode === ThemeMode.DARK) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [themeMode]);

  const handleLoginSuccess = (user: User) => {
    setCurrentUser(user);
    // Add positive tracking
    addSystemNotification(
      'Hệ thống trực tuyến',
      `Người dùng ${user.name} vừa đăng nhập không gian làm việc phòng ${user.department}.`,
      'system'
    );
  };

  const handleLogout = () => {
    DB.setCurrentUser(null);
    setCurrentUser(null);
    setCurrentTab('dashboard');
  };

  const addSystemNotification = (title: string, content: string, type: 'task' | 'comment' | 'ai' | 'system') => {
    const newNotif: Notification = {
      id: 'notif_' + Date.now(),
      title,
      content,
      type,
      createdAt: new Date().toISOString(),
      read: false
    };
    const updated = [newNotif, ...notifications];
    setNotifications(updated);
    DB.saveNotifications(updated);
  };

  const handleImportSuccess = (imported: Task[]) => {
    // Reload components list & state
    const freshlyLoaded = DB.getTasks();
    setTasks(freshlyLoaded);
    addSystemNotification(
      'Hộp Kế Hoạch Đã Nạp',
      `AI vừa phân tích và bóc tách thành công ${imported.length} đầu việc từ danh mục Excel mẫu của bạn.`,
      'ai'
    );
    // Redirect to Tasks board list instantly so the user sees results!
    setCurrentTab('tasks');
  };

  // If session is unauthenticated, show corporate login page exclusively
  if (!currentUser) {
    return <Login onLoginSuccess={handleLoginSuccess} />;
  }

  const unreadNotificationsCount = notifications.filter(n => !n.read).length;

  return (
    <div className="min-h-screen font-sans flex flex-col lg:flex-row frosted-bg text-slate-800 dark:text-slate-100 transition-colors duration-300">
      
      {/* Sidebar & Touch Bottom layouts switcher */}
      <Navigation
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        currentUser={currentUser}
        onLogout={handleLogout}
        unreadCount={unreadNotificationsCount}
      />

      {/* Primary Workstation Scroll Canvas */}
      <main className="flex-1 overflow-y-auto pb-24 lg:pb-6 relative h-screen">
        
        {/* Department Banner Header for desktop */}
        <header className="hidden lg:flex justify-between items-center px-8 py-3 glass-header shrink-0">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-500 glow-animation" />
            <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">
              Cổng Điều Hành Hoạt Động Tín Dân CRM | Vivian Label System
            </span>
          </div>

          <div className="text-xs text-slate-450 dark:text-slate-350 font-mono flex items-center gap-2">
            <span>Thời gian hệ thống (Thực tế):</span>
            <span className="font-bold text-blue-650 dark:text-blue-400 bg-blue-50 dark:bg-slate-800 px-2.5 py-1 rounded-md border border-blue-105 dark:border-slate-700">
              {currentTime.toLocaleDateString('vi-VN')} {currentTime.toLocaleTimeString('vi-VN')}
            </span>
          </div>
        </header>

        {/* Dynamic Panel Switching routing board */}
        <div className="relative animate-fade-in">
          {currentTab === 'dashboard' && (
            <Dashboard
              currentUser={currentUser}
              onSetTab={setCurrentTab}
              tasks={tasks}
              setTasks={setTasks}
              notifications={notifications}
              setNotifications={setNotifications}
              kpis={kpis}
            />
          )}

          {currentTab === 'tasks' && (
            <Tasks
              currentUser={currentUser}
              tasks={tasks}
              setTasks={setTasks}
              comments={comments}
              setComments={setComments}
            />
          )}

          {currentTab === 'projects' && (
            <ProjectManager
              currentUser={currentUser}
              projects={projects}
              setProjects={setProjects}
              tasks={tasks}
              setTasks={setTasks}
            />
          )}

          {currentTab === 'excel-import' && (
            <AIImport
              currentUser={currentUser}
              onImportComplete={handleImportSuccess}
            />
          )}

          {currentTab === 'reports' && (
            <AIReports
              currentUser={currentUser}
              tasks={tasks}
              kpis={kpis}
            />
          )}

          {currentTab === 'kpis' && (
            <KPIManager
              currentUser={currentUser}
              kpis={kpis}
              setKpis={setKpis}
              onAddNotification={addSystemNotification}
            />
          )}

          {currentTab === 'assistant' && (
            <AIAssistant
              currentUser={currentUser}
            />
          )}

          {currentTab === 'files' && (
            <FileCenter
              currentUser={currentUser}
            />
          )}

          {currentTab === 'settings' && (
            <Settings
              currentUser={currentUser}
              themeMode={themeMode}
              setThemeMode={setThemeMode}
              onAddNotification={addSystemNotification}
            />
          )}

          {currentTab === 'users' && (
            <Users
              currentUser={currentUser}
              onAddNotification={addSystemNotification}
            />
          )}
        </div>

      </main>

      <AIQuickActionBar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        currentUser={currentUser}
        tasks={tasks}
        setTasks={setTasks}
        projects={projects}
        setProjects={setProjects}
        onAddNotification={addSystemNotification}
      />
      
    </div>
  );
}

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore, doc, getDocFromServer, setLogLevel } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId); /* CRITICAL: The app will break without this line */
export const auth = getAuth();

// Mute Firestore warning logs by setting log level to silent
try {
  setLogLevel('silent');
} catch (e) {
  // Ignore any log level initialization errors
}

// Active Firestore flag to block operations dynamically if offline or invalid credentials
export let isFirestoreActive = true;

export function setFirestoreActive(active: boolean) {
  isFirestoreActive = active;
  if (!active) {
    console.warn("[Tín Dân Firebase] Silently deactivated online Firestore syncing. Running purely offline via high-performance LocalStorage.");
  }
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  
  console.warn('[Tín Dân Firebase] Suppressing Firestore exception to maintain stable execution:', JSON.stringify(errInfo));
  
  // Quietly turn off future Firestore attempts
  setFirestoreActive(false);
}

// Verification connection to Firestore directly at boot with a short 2.5s threshold
async function testConnection() {
  const timeoutPromise = new Promise<never>((_, reject) =>
    setTimeout(() => reject(new Error('connection_timeout')), 2500)
  );

  try {
    await Promise.race([
      getDocFromServer(doc(db, 'test', 'connection')),
      timeoutPromise
    ]);
    isFirestoreActive = true;
    console.log("[Tín Dân Firebase] Firebase connection verified successfully.");
  } catch (error) {
    isFirestoreActive = false;
    console.warn("[Tín Dân Firebase] Firestore cannot be reached. Swapping transparently to ultra-fast client-side caching.");
  }
}
testConnection();

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { db, handleFirestoreError, OperationType, isFirestoreActive } from './firebase';
import { collection, onSnapshot, getDocs, doc, setDoc } from 'firebase/firestore';
import { setStored, DB } from './dataStore';

// Baseline seed default data when Firestore is empty
export async function seedFirestoreIfEmpty() {
  if (!isFirestoreActive) return;
  try {
    const projectsSnapshot = await getDocs(collection(db, 'projects'));
    if (projectsSnapshot.empty) {
      console.log("Firestore projects list is empty. Initializing baseline cloud dataset...");
      
      const seedData: Record<string, any[]> = {
        users: DB.getUsers(),
        projects: DB.getProjects(),
        tasks: DB.getTasks(),
        comments: DB.getComments(),
        notifications: DB.getNotifications(),
        kpis: DB.getKPIs(),
        activity_logs: DB.getActivityLogs(),
        task_analysis: DB.getTaskAnalyses(),
        ai_kpi_logs: DB.getAiKpiLogs(),
        ai_reports: DB.getAiReports(),
        daily_summaries: DB.getDailySummaries(),
        weekly_summaries: DB.getWeeklySummaries(),
        monthly_summaries: DB.getMonthlySummaries(),
        notification_logs: DB.getNotificationLogs(),
        task_risk_scores: DB.getTaskRiskScores(),
        employee_workload: DB.getEmployeeWorkloads(),
        ai_deadline_suggestions: DB.getAiDeadlineSuggestions()
      };

      for (const [collectionName, items] of Object.entries(seedData)) {
        for (const item of items) {
          if (item && item.id) {
            await setDoc(doc(db, collectionName, item.id), item);
          }
        }
      }
      console.log("Firestore cloud dataset seeded perfectly.");
    }
  } catch (error) {
    console.warn("Seeding baseline skipped or errored (expected on locked operations):", error);
  }
}

interface FirebaseSyncCallbacks {
  onTasksChange: (tasks: any[]) => void;
  onProjectsChange: (projects: any[]) => void;
  onCommentsChange: (comments: any[]) => void;
  onKPIsChange: (kpis: any[]) => void;
  onNotificationsChange: (notifications: any[]) => void;
}

export function subscribeToFirebaseUpdates(callbacks: FirebaseSyncCallbacks) {
  if (!isFirestoreActive) {
    console.info("[Tín Dân Sync] Offline state active. Operating purely via localStorage.");
    return () => {};
  }
  const unsubscribes: (() => void)[] = [];

  const syncTargets = [
    { name: 'tasks', callback: callbacks.onTasksChange },
    { name: 'projects', callback: callbacks.onProjectsChange },
    { name: 'comments', callback: callbacks.onCommentsChange },
    { name: 'kpis', callback: callbacks.onKPIsChange },
    { name: 'notifications', callback: callbacks.onNotificationsChange }
  ];

  syncTargets.forEach(({ name, callback }) => {
    try {
      const unsub = onSnapshot(collection(db, name), (snapshot) => {
        const items = snapshot.docs.map(docDoc => docDoc.data());
        // Propagate down to localStorage cache so synchronous DB references are always live
        setStored(name, items);
        // Dispatch React state updating callback
        callback(items);
      }, (error) => {
        handleFirestoreError(error, OperationType.LIST, name);
      });
      unsubscribes.push(unsub);
    } catch (err) {
      console.warn(`Firestore subscription failed to setup for ${name}:`, err);
    }
  });

  return () => {
    unsubscribes.forEach(unsub => {
      try {
        unsub();
      } catch (err) {
        // ignore
      }
    });
  };
}

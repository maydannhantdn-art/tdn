/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { 
  User, 
  UserRole, 
  Department, 
  Task, 
  TaskPriority, 
  TaskStatus, 
  Project, 
  KPIs, 
  AISettings, 
  Notification, 
  ThemeMode, 
  TaskComment,
  TaskActivityLog,
  AiTaskAnalysis,
  AiKpiLog,
  AiReport,
  DailySummary,
  WeeklySummary,
  MonthlySummary,
  NotificationLog,
  TaskRiskScore,
  EmployeeWorkload,
  AiDeadlineSuggestion
} from '../types';

// Baseline seeded users
const DEFAULT_USERS: User[] = [
  { id: 'u1', email: 'tindancompany22@gmail.com', name: 'Trần Tuấn Anh (Sếp Tín Dân)', role: UserRole.SUPER_ADMIN, department: Department.ADMIN, status: 'active', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face' },
  { id: 'u2', email: 'marketing.tin@gmail.com', name: 'Nguyễn Văn Nam', role: UserRole.MANAGER, department: Department.MARKETING, status: 'active', avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&h=150&fit=crop&crop=face' },
  { id: 'u3', email: 'sales.tin@gmail.com', name: 'Lê Thị Thuỷ', role: UserRole.EMPLOYEE, department: Department.SALE, status: 'active', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop&crop=face' },
  { id: 'u4', email: 'cskh.tin@gmail.com', name: 'Phạm Minh Hải', role: UserRole.EMPLOYEE, department: Department.CSKH, status: 'active', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face' },
  { id: 'u5', email: 'tech.tin@gmail.com', name: 'Trần Minh Đức', role: UserRole.EMPLOYEE, department: Department.KY_THUAT, status: 'active', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop&crop=face' },
  { id: 'u6', email: 'kho.tin@gmail.com', name: 'Phùng Lê Huy', role: UserRole.EMPLOYEE, department: Department.KHO, status: 'active', avatar: 'https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?w=150&h=150&fit=crop&crop=face' },
  { id: 'u7', email: 'ketoan.tin@gmail.com', name: 'Hoàng Phương Thảo', role: UserRole.EMPLOYEE, department: Department.KE_TOAN, status: 'active', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face' }
];

// Baseline seeded projects
const DEFAULT_PROJECTS: Project[] = [
  { id: 'p1', name: 'Marketing Bao Bì VF5', code: 'PRO-MARK-VF5', description: 'Chiến dịch đẩy mạnh sản phẩm tem nhãn mác dán & bao bì cho VF5', progress: 65, department: Department.MARKETING, status: 'active' },
  { id: 'p2', name: 'Tối ưu Năng suất Xưởng Tem Vivian', code: 'PRO-MAN-VIVIAN', description: 'Nâng cấp máy móc tự động và tối ưu hóa file thiết kế in decal cuộn', progress: 40, department: Department.KY_THUAT, status: 'active' },
  { id: 'p3', name: 'Tái cấu trúc CSKH Đại lý', code: 'PRO-CS-RECON', description: 'Triển khai CRM cho đại lý và quy trình đổi trả hàng tự động', progress: 85, department: Department.CSKH, status: 'active' },
  { id: 'p4', name: 'Hợp đồng Sales Thép & Nhựa Tín Dân', code: 'PRO-SALE-PLAST', description: 'Ký kết và phân phối nhãn mác chất lượng cao cho các đại lý công nghiệp', progress: 10, department: Department.SALE, status: 'planning' }
];

// Baseline seeded tasks
const DEFAULT_TASKS: Task[] = [
  {
    id: 't1',
    projectId: 'p1',
    projectName: 'Marketing Bao Bì VF5',
    title: 'Thiết kế trọn bộ Banner chiến dịch VF5',
    description: 'Thiết kế bộ ấn phẩm gồm Standee, Banner Facebook, Poster để chuẩn bị ra mắt chiến dịch tem decal dán bao bì VF5.',
    checklist: [
      { id: 'tc1', title: 'Thiết kế mẫu phác thảo', done: true },
      { id: 'tc2', title: 'Xuất file in chất lượng cao', done: true },
      { id: 'tc3', title: 'Đăng lên Drive truyền thông xưởng', done: false }
    ],
    deadline: '2026-06-15',
    assignee: 'Nguyễn Văn Nam',
    department: Department.MARKETING,
    priority: TaskPriority.HIGH,
    status: TaskStatus.IN_PROGRESS,
    attachments: ['VF5_concept_draft.png', 'Standee_VF5.pdf'],
    commentsCount: 2,
    kpiScore: 15,
    planMonth: 'June',
    planWeek: 'Week 1'
  },
  {
    id: 't2',
    projectId: 'p1',
    projectName: 'Marketing Bao Bì VF5',
    title: 'Chạy quảng cáo Facebook Ads tăng CPL mục tiêu',
    description: 'Set up các nhóm quảng cáo nhắm chọn xưởng sản xuất thực phẩm, dược phẩm cần in nhãn mác tự dính.',
    checklist: [
      { id: 'tc4', title: 'Soạn nội dung bài viết', done: true },
      { id: 'tc5', title: 'Cài đặt ngân sách 20tr/tháng', done: true }
    ],
    deadline: '2026-06-08',
    assignee: 'Nguyễn Văn Nam',
    department: Department.MARKETING,
    priority: TaskPriority.HIGH,
    status: TaskStatus.DONE,
    attachments: [],
    commentsCount: 0,
    kpiScore: 20,
    planMonth: 'June',
    planWeek: 'Week 1'
  },
  {
    id: 't3',
    projectId: 'p2',
    projectName: 'Tối ưu Năng suất Xưởng Tem Vivian',
    title: 'Kiểm tra bảo dưỡng định kỳ máy in UV cuộn',
    description: 'Yêu cầu kiểm tra đầu phun đầu in UV xưởng Tem Vivian để tránh sọc sản phẩm in decal, lập báo cáo gửi sếp.',
    checklist: [
      { id: 'tc6', title: 'Vệ sinh hệ thống cấp mực', done: false },
      { id: 'tc7', title: 'Cân chỉnh thấu kính đèn UV', done: false },
      { id: 'tc8', title: 'Test mẫu in chất lượng', done: false }
    ],
    deadline: '2026-06-03', // Overdue
    assignee: 'Trần Minh Đức',
    department: Department.KY_THUAT,
    priority: TaskPriority.HIGH,
    status: TaskStatus.IN_PROGRESS,
    attachments: [],
    commentsCount: 1,
    kpiScore: 10,
    planMonth: 'June',
    planWeek: 'Week 1',
    overdueRisk: true
  },
  {
    id: 't4',
    projectId: 'p3',
    projectName: 'Tái cấu trúc CSKH Đại lý',
    title: 'Xây dựng kịch bản phản hồi tự động Zalo ZNS',
    description: 'Tạo lập nội dung tin nhắn Zalo chăm sóc sau khi giao lô tem nhãn thành công để nhận đánh giá hài lòng.',
    checklist: [
      { id: 'tc9', title: 'Duyệt mẫu tin nhắn ZNS với Zalo', done: true },
      { id: 'tc10', title: 'Tích hợp webhook thông báo', done: true }
    ],
    deadline: '2026-06-10',
    assignee: 'Phạm Minh Hải',
    department: Department.CSKH,
    priority: TaskPriority.MEDIUM,
    status: TaskStatus.DONE,
    attachments: [],
    commentsCount: 0,
    kpiScore: 12,
    planMonth: 'June',
    planWeek: 'Week 2'
  }
];

// Background baseline comments
const DEFAULT_COMMENTS: TaskComment[] = [
  { id: 'c1', taskId: 't1', userId: 'u1', userName: 'Trần Tuấn Anh (Sếp Tín Dân)', userRole: 'Super Admin', content: 'Thiết kế cần lưu ý sử dụng tông màu đồng bộ với logo Tem Vivian nhé Nam.', createdAt: '2026-06-04T08:00:00Z' },
  { id: 'c2', taskId: 't1', userId: 'u2', userName: 'Nguyễn Văn Nam', userRole: 'Manager', content: 'Dạ sếp, em đang cho thiết kế áp dụng mã màu chuẩn của thương hiệu ạ!', createdAt: '2026-06-04T08:30:00Z' },
  { id: 'c3', taskId: 't3', userId: 'u1', userName: 'Trần Tuấn Anh (Sếp Tín Dân)', userRole: 'Super Admin', content: 'Đức ơi, máy này rất quan trọng cho lô tem tuần sau, cập nhật tiến độ gấp nhé.', createdAt: '2026-06-03T10:00:00Z' }
];

// Baseline reports log
const DEFAULT_NOTIFICATIONS: Notification[] = [
  { id: 'n1', title: 'Nhiệm vụ sắp trễ hạn', content: 'Công việc "Kiểm tra bảo dưỡng định kỳ máy in UV cuộn" đã trễ hạn 1 ngày. Nhắc nhở kỹ thuật Trần Minh Đức xử lý lập tức.', type: 'task', createdAt: '2026-06-04T10:00:00Z', read: false },
  { id: 'n2', title: 'Đã nhập kế hoạch Excel bằng AI', content: 'Hệ thống AI vừa xử lý thành công File Kế hoạch Tín Dân Q2, đã phân loại tự động 4 đầu việc chính.', type: 'ai', createdAt: '2026-06-04T09:15:00Z', read: false }
];

// Baseline KPI scores
const DEFAULT_KPIS: KPIs[] = [
  { id: 'k1', employeeName: 'Nguyễn Văn Nam', department: Department.MARKETING, month: '06/2026', totalTasks: 8, completedTasks: 6, overdueTasks: 0, kpiScore: 85, weeklyProgress: [80, 85, 90, 85], notes: 'Tiến độ rất xuất sắc, mảng Marketing tiếp cận khách hàng online tốt.' },
  { id: 'k2', employeeName: 'Lê Thị Thuỷ', department: Department.SALE, month: '06/2026', totalTasks: 5, completedTasks: 2, overdueTasks: 1, kpiScore: 68, weeklyProgress: [60, 70, 65, 70], notes: 'Cần bám sát khách hàng mua nhãn dán công nghiệp hơn nữa.' },
  { id: 'k3', employeeName: 'Trần Minh Đức', department: Department.KY_THUAT, month: '06/2026', totalTasks: 6, completedTasks: 4, overdueTasks: 1, kpiScore: 72, weeklyProgress: [70, 75, 72, 70], notes: 'Có 1 đầu việc bị quá hạn, cần kịp thời báo cáo khi máy xưởng gặp sự cố.' },
  { id: 'k4', employeeName: 'Phạm Minh Hải', department: Department.CSKH, month: '06/2026', totalTasks: 10, completedTasks: 9, overdueTasks: 0, kpiScore: 92, weeklyProgress: [90, 92, 95, 93], notes: 'Hoàn thành hầu hết các kịch bản phản hồi nhanh, điểm hài lòng đại lý cao.' }
];

const DEFAULT_AI_SETTINGS: AISettings = {
  provider: 'gemini',
  model: 'gemini-3.5-flash',
  cheapMode: false,
  fastMode: true,
  tokenUsed: 2384,
  aiToolsEnabled: true
};

// Seed values for CRM database upgrades
const DEFAULT_ACTIVITY_LOGS: TaskActivityLog[] = [
  { id: 'al1', taskId: 't1', taskTitle: 'Thiết kế trọn bộ Banner chiến dịch VF5', userId: 'u2', userName: 'Nguyễn Văn Nam', actionType: 'checklist_update', description: 'Đã hoàn thành mục: Thiết kế mẫu phác thảo', createdAt: '2026-06-04T12:00:00Z' },
  { id: 'al2', taskId: 't3', taskTitle: 'Kiểm tra bảo dưỡng định kỳ máy in UV cuộn', userId: 'u5', userName: 'Trần Minh Đức', actionType: 'status_change', description: 'Đã chuyển trạng thái từ Pending sang In Progress', createdAt: '2026-06-03T09:12:00Z' },
  { id: 'al3', taskId: 't3', taskTitle: 'Kiểm tra bảo dưỡng định kỳ máy in UV cuộn', userId: 'u1', userName: 'Trần Tuấn Anh (Sếp Tín Dân)', actionType: 'comment', description: 'Đã thêm bình luận: "Đức ơi, máy này rất quan trọng cho lô tem..."', createdAt: '2026-06-03T10:00:00Z' },
  { id: 'al4', taskId: 't4', taskTitle: 'Xây dựng kịch bản phản hồi tự động Zalo ZNS', userId: 'u4', userName: 'Phạm Minh Hải', actionType: 'ai_action', description: 'AI đã tự động tinh chỉnh và tạo danh sách 4 bước checklist mẫu', createdAt: '2026-06-04T14:30:00Z' }
];

const DEFAULT_AI_TASK_ANALYSES: AiTaskAnalysis[] = [
  { id: 'ana1', taskId: 't1', healthScore: 88, riskScore: 12, durationPredictionDays: 8, tags: ['marketing', 'design'], suggestedDeadline: '2026-06-15', isUnrealisticDeadline: false, workloadScore: 40, recommendations: ['Để đẩy nhanh tiến độ làm việc, hãy chuyển bớt tài liệu in nhãn cho đại lý phụ.'] },
  { id: 'ana2', taskId: 't3', healthScore: 45, riskScore: 78, durationPredictionDays: 4, tags: ['technical', 'urgent'], suggestedDeadline: '2026-06-06', isUnrealisticDeadline: true, workloadScore: 85, recommendations: ['Đang có dấu hiệu quá tải. Máy in UV kẹt ống phun. Khuyên phân công backup: Phùng Lê Huy.'] }
];

const DEFAULT_AI_KPI_LOGS: AiKpiLog[] = [
  { id: 'akl1', userId: 'u2', userName: 'Nguyễn Văn Nam', department: Department.MARKETING, month: '06/2026', completionScore: 85, overdueScore: 0, productivityScore: 90, weeklyKPIs: [80, 85, 90, 85], monthlyKPI: 85, trendDirection: 'up', suggestions: ['Duy trì nhịp chạy Facebook Ads để tiếp cận sâu khách hàng bao bì tốt.'] },
  { id: 'akl2', userId: 'u5', userName: 'Trần Minh Đức', department: Department.KY_THUAT, month: '06/2026', completionScore: 68, overdueScore: 75, productivityScore: 70, weeklyKPIs: [70, 75, 72, 70], monthlyKPI: 72, trendDirection: 'stable', suggestions: ['Có nhiệm vụ trễ hạn, cần hỗ trợ từ nhân viên Kho Phùng Lê Huy để giảm tải tải trọng.'] }
];

const DEFAULT_AI_REPORTS: AiReport[] = [
  { id: 'rep1', title: 'Phân Tích Năng Suất Vận Hành Tuần 1 Tháng 6', reportType: 'weekly', generatedBy: 'Tín Dân Executive AI', content: 'KPI vận hành bình quân đạt 79đ. Phòng CSKH dẫn đầu mảng số hóa. Phòng kỹ thuật nghẽn thiết bị.', createdAt: '2026-06-04T18:00:00Z', kpisIncluded: ['Marketing', 'Kỹ thuật', 'CSKH'], overdueTasksCount: 1, aiInsightsSummary: 'Cần phân phối đều nguồn lực để tháo gỡ điểm nghẽn máy UV xưởng Vivian.' }
];

const DEFAULT_DAILY_SUMMARIES: DailySummary[] = [
  {
    id: 'ds1',
    date: '2026-06-04',
    completedTasks: ['Xây dựng kịch bản phản hồi tự động Zalo ZNS'],
    overdueTasks: ['Kiểm tra bảo dưỡng định kỳ máy in UV cuộn'],
    blockedTasks: [],
    employeeProgressSummary: 'Phạm Minh Hải hoàn thành 100% công việc của mình.',
    departmentProgressSummary: 'CSKH hoàn thành tốt, Kỹ thuật bị tắc nghẽn nhẹ.',
    managerSummary: 'Sếp Tuấn Anh: Tổng quan vận hành ổn định. Chú ý thiết bị bảo dưỡng định kỳ máy UV xưởng.',
    employeeSummary: 'Đội ngũ: Nam và Đức chủ động tiến độ. Hải thực hiện bám sát mục tiêu.',
    sentToTelegram: true,
    sentToZalo: true
  }
];

const DEFAULT_WEEKLY_SUMMARIES: WeeklySummary[] = [
  { id: 'ws1', weekLabel: 'Tuần 1 - Tháng 6', completedTasksCount: 12, overdueTasksCount: 1, blockedTasksCount: 0, trendReport: 'Tập trung chủ yếu vào việc in sấy UV decal và CSKH đại lý mác dán.', suggestions: ['Tối ưu quy trình in từ khâu nhận file thiết kế.'] }
];

const DEFAULT_MONTHLY_SUMMARIES: MonthlySummary[] = [
  { id: 'ms1', monthLabel: 'Tháng 6/2026', performanceInsights: 'Tháng này có sự bứt phá về tối ưu in ấn Vivian nhờ tích hợp AI Planner.', topPerformers: ['Phạm Minh Hải', 'Nguyễn Văn Nam'], bottlenecksIdentified: ['Vệ sinh hệ thống cấp mực máy UV'] }
];

const DEFAULT_NOTIFICATION_LOGS: NotificationLog[] = [
  { id: 'nl1', title: '🔔 Hết hạn công việc', content: 'Task: Kiểm tra bảo dưỡng định kỳ máy in UV cuộn đang bị trễ hạn.', type: 'sound_bell', createdAt: '2026-06-04T18:00:00Z', read: false },
  { id: 'nl2', title: '📱 Thông báo đẩy Zalo/Telegram', content: 'Đã báo cáo EOD lên nhóm quản trị sếp Trần Tuấn Anh.', type: 'mobile_push', createdAt: '2026-06-04T18:30:00Z', read: true }
];

const DEFAULT_TASK_RISK_SCORES: TaskRiskScore[] = [
  { id: 'trs1', taskId: 't3', taskTitle: 'Kiểm tra bảo dưỡng định kỳ máy in UV cuộn', riskScore: 78, riskLevel: 'high', reason: 'Chưa có hoạt động cập nhật 3 ngày trong khi đã trễ hạn.', solution: 'Ủy quyền khẩn cấp hoặc gửi thông báo dồn dập cho Trần Minh Đức.', updatedAt: '2026-06-04T18:40:00Z' }
];

const DEFAULT_EMPLOYEE_WORKLOAD: EmployeeWorkload[] = [
  { id: 'wkl1', userId: 'u2', userName: 'Nguyễn Văn Nam', department: Department.MARKETING, currentTasksCount: 2, weeklyCapacityHrs: 40, allocatedHrs: 25, overloadRisk: false, recommendations: ['Khối lượng công việc ổn định, có thể nhận thêm việc hỗ trợ thiết kế.'] },
  { id: 'wkl2', userId: 'u5', userName: 'Trần Minh Đức', department: Department.KY_THUAT, currentTasksCount: 3, weeklyCapacityHrs: 40, allocatedHrs: 45, overloadRisk: true, recommendations: ['Đang quá tải nhiệm vụ vận hành UV Vivian. Cần điều bớt task bảo quản đèn cho Phùng Lê Huy.'] }
];

const DEFAULT_DEADLINE_SUGGESTIONS: AiDeadlineSuggestion[] = [
  { id: 'ads1', taskId: 't1', taskTitle: 'Thiết kế trọn bộ Banner chiến dịch VF5', suggestedDeadline: '2026-06-15', complexity: 'medium', reason: 'Thiết kế thương hiệu bao bì cần 2-3 hôm sửa marquette nên hạn chót này là hợp lý.', isUnrealistic: false },
  { id: 'ads2', taskId: 't3', taskTitle: 'Kiểm tra bảo dưỡng định kỳ máy in UV cuộn', suggestedDeadline: '2026-06-06', complexity: 'complex', reason: 'Đầu phun kẹt mực cần vệ sinh tỉ mỉ. Hạn ban đầu trễ nguy hiểm, khuyên chỉnh muộn thêm 2 ngày.', isUnrealistic: true }
];

// Local storage namespacing helpers
export const fetchStored = <T>(key: string, defaultValue: T): T => {
  try {
    const item = localStorage.getItem(`tindan_crm_${key}`);
    return item ? JSON.parse(item) : defaultValue;
  } catch (error) {
    console.warn(`Error reading localStorage for key ${key}`, error);
    return defaultValue;
  }
};

export const setStored = <T>(key: string, value: T): void => {
  try {
    localStorage.setItem(`tindan_crm_${key}`, JSON.stringify(value));
  } catch (error) {
    console.warn(`Error writing localStorage for key ${key}`, error);
  }
};

// Firestore integration for active state writes
import { doc, setDoc, deleteDoc } from 'firebase/firestore';
import { db, isFirestoreActive, setFirestoreActive } from './firebase';

const syncItemToFirestore = async (collectionPath: string, id: string, item: any) => {
  if (!isFirestoreActive) return;
  try {
    const docRef = doc(db, collectionPath, id);
    await setDoc(docRef, item);
  } catch (error) {
    console.warn(`Failed to sync to Firestore: ${collectionPath}/${id}`, error);
    // Silent failover to offline-only execution
    setFirestoreActive(false);
  }
};

const deleteItemFromFirestore = async (collectionPath: string, id: string) => {
  if (!isFirestoreActive) return;
  try {
    const docRef = doc(db, collectionPath, id);
    await deleteDoc(docRef);
  } catch (error) {
    console.warn(`Failed to delete from Firestore: ${collectionPath}/${id}`, error);
    // Silent failover to offline-only execution
    setFirestoreActive(false);
  }
};

export const syncCollection = async <T extends { id: string }>(
  collectionName: string,
  newItems: T[]
) => {
  const existingItems = fetchStored<T[]>(collectionName, []);
  setStored(collectionName, newItems);

  if (!isFirestoreActive) return;

  // Sync to Firestore in the background
  newItems.forEach(item => {
    if (item && item.id) {
      syncItemToFirestore(collectionName, item.id, item);
    }
  });

  // Sync deletes to Firestore
  const newIds = new Set(newItems.map(item => item.id));
  existingItems.forEach(item => {
    if (item && item.id && !newIds.has(item.id)) {
      deleteItemFromFirestore(collectionName, item.id);
    }
  });
};

export const clearAllDataStore = () => {
  localStorage.removeItem('tindan_crm_users');
  localStorage.removeItem('tindan_crm_projects');
  localStorage.removeItem('tindan_crm_tasks');
  localStorage.removeItem('tindan_crm_comments');
  localStorage.removeItem('tindan_crm_notifications');
  localStorage.removeItem('tindan_crm_kpis');
  localStorage.removeItem('tindan_crm_current_user');
  localStorage.removeItem('tindan_crm_ai_settings');
  localStorage.removeItem('tindan_crm_theme');
  localStorage.removeItem('tindan_crm_activity_logs');
  localStorage.removeItem('tindan_crm_task_analysis');
  localStorage.removeItem('tindan_crm_ai_kpi_logs');
  localStorage.removeItem('tindan_crm_ai_reports');
  localStorage.removeItem('tindan_crm_daily_summaries');
  localStorage.removeItem('tindan_crm_weekly_summaries');
  localStorage.removeItem('tindan_crm_monthly_summaries');
  localStorage.removeItem('tindan_crm_notification_logs');
  localStorage.removeItem('tindan_crm_task_risk_scores');
  localStorage.removeItem('tindan_crm_employee_workload');
  localStorage.removeItem('tindan_crm_ai_deadline_suggestions');
  window.location.reload();
};

// Export active getter / setter APIs
export const DB = {
  getUsers: (): User[] => fetchStored('users', DEFAULT_USERS),
  saveUsers: (users: User[]) => syncCollection('users', users),

  getCurrentUser: (): User | null => fetchStored<User | null>('current_user', DEFAULT_USERS[0]), // Default logged in as Trần Tuấn Anh (Sếp)
  setCurrentUser: (user: User | null) => setStored('current_user', user),

  getTasks: (): Task[] => fetchStored('tasks', DEFAULT_TASKS),
  saveTasks: (tasks: Task[]) => syncCollection('tasks', tasks),

  getProjects: (): Project[] => fetchStored('projects', DEFAULT_PROJECTS),
  saveProjects: (projects: Project[]) => syncCollection('projects', projects),

  getComments: (): TaskComment[] => fetchStored('comments', DEFAULT_COMMENTS),
  saveComments: (comments: TaskComment[]) => syncCollection('comments', comments),

  getNotifications: (): Notification[] => fetchStored('notifications', DEFAULT_NOTIFICATIONS),
  saveNotifications: (notifications: Notification[]) => syncCollection('notifications', notifications),

  getKPIs: (): KPIs[] => fetchStored('kpis', DEFAULT_KPIS),
  saveKPIs: (kpis: KPIs[]) => syncCollection('kpis', kpis),

  getAISettings: (): AISettings => fetchStored('ai_settings', DEFAULT_AI_SETTINGS),
  saveAISettings: (settings: AISettings) => setStored('ai_settings', settings),

  getTheme: (): ThemeMode => fetchStored('theme', ThemeMode.BLUE_AI),
  saveTheme: (theme: ThemeMode) => setStored('theme', theme),

  // Setters/Getters for the upgraded AI collections
  getActivityLogs: (): TaskActivityLog[] => fetchStored('activity_logs', DEFAULT_ACTIVITY_LOGS),
  saveActivityLogs: (logs: TaskActivityLog[]) => syncCollection('activity_logs', logs),

  getTaskAnalyses: (): AiTaskAnalysis[] => fetchStored('task_analysis', DEFAULT_AI_TASK_ANALYSES),
  saveTaskAnalyses: (analyses: AiTaskAnalysis[]) => syncCollection('task_analysis', analyses),

  getAiKpiLogs: (): AiKpiLog[] => fetchStored('ai_kpi_logs', DEFAULT_AI_KPI_LOGS),
  saveAiKpiLogs: (logs: AiKpiLog[]) => syncCollection('ai_kpi_logs', logs),

  getAiReports: (): AiReport[] => fetchStored('ai_reports', DEFAULT_AI_REPORTS),
  saveAiReports: (reports: AiReport[]) => syncCollection('ai_reports', reports),

  getDailySummaries: (): DailySummary[] => fetchStored('daily_summaries', DEFAULT_DAILY_SUMMARIES),
  saveDailySummaries: (sums: DailySummary[]) => syncCollection('daily_summaries', sums),

  getWeeklySummaries: (): WeeklySummary[] => fetchStored('weekly_summaries', DEFAULT_WEEKLY_SUMMARIES),
  saveWeeklySummaries: (sums: WeeklySummary[]) => syncCollection('weekly_summaries', sums),

  getMonthlySummaries: (): MonthlySummary[] => fetchStored('monthly_summaries', DEFAULT_MONTHLY_SUMMARIES),
  saveMonthlySummaries: (sums: MonthlySummary[]) => syncCollection('monthly_summaries', sums),

  getNotificationLogs: (): NotificationLog[] => fetchStored('notification_logs', DEFAULT_NOTIFICATION_LOGS),
  saveNotificationLogs: (logs: NotificationLog[]) => syncCollection('notification_logs', logs),

  getTaskRiskScores: (): TaskRiskScore[] => fetchStored('task_risk_scores', DEFAULT_TASK_RISK_SCORES),
  saveTaskRiskScores: (scores: TaskRiskScore[]) => syncCollection('task_risk_scores', scores),

  getEmployeeWorkloads: (): EmployeeWorkload[] => fetchStored('employee_workload', DEFAULT_EMPLOYEE_WORKLOAD),
  saveEmployeeWorkloads: (workloads: EmployeeWorkload[]) => syncCollection('employee_workload', workloads),

  getAiDeadlineSuggestions: (): AiDeadlineSuggestion[] => fetchStored('ai_deadline_suggestions', DEFAULT_DEADLINE_SUGGESTIONS),
  saveAiDeadlineSuggestions: (sugs: AiDeadlineSuggestion[]) => syncCollection('ai_deadline_suggestions', sugs)
};

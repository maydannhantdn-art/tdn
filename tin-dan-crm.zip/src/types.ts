/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum UserRole {
  SUPER_ADMIN = 'Super Admin',
  ADMIN = 'Admin',
  MANAGER = 'Manager',
  EMPLOYEE = 'Employee'
}

export enum Department {
  MARKETING = 'Marketing',
  SALE = 'Sale',
  CSKH = 'CSKH',
  KY_THUAT = 'Kỹ thuật',
  KHO = 'Kho',
  KE_TOAN = 'Kế toán',
  ADMIN = 'Admin'
}

export enum TaskPriority {
  LOW = 'Low',
  MEDIUM = 'Medium',
  HIGH = 'High'
}

export enum TaskStatus {
  PENDING = 'Pending',
  IN_PROGRESS = 'In Progress',
  DONE = 'Done'
}

export enum ThemeMode {
  LIGHT = 'light',
  DARK = 'dark',
  BLUE_AI = 'blue-ai'
}

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  department: Department;
  status: 'active' | 'locked';
  avatar?: string;
  position?: string; // Chức vụ phòng ban
  password?: string; // Mật khẩu truy cập
  permissions?: {
    canCreateTask: boolean;
    canEditTask: boolean;
    canDeleteTask: boolean;
    canBonusKPI: boolean;
    canExportReport: boolean;
    canUseAI: boolean; // Quyền hạn được sử dụng AI
  };
}

export interface ChecklistItem {
  id: string;
  title: string;
  done: boolean;
}

export interface TaskComment {
  id: string;
  taskId: string;
  userId: string;
  userName: string;
  userRole: string;
  content: string;
  createdAt: string;
}

export interface Task {
  id: string;
  projectId: string;
  projectName?: string;
  title: string;
  description: string;
  checklist: ChecklistItem[];
  deadline: string;
  assignee: string; // Tên nhân viên hoặc email
  coWorkers?: string[]; // Người liên quan
  createdAtDate?: string; // Ngày tạo task
  resultNotes?: string; // Phần nhập kết quả cho [Lead]/[nhóm]/[zalo]/[facebook]
  department: Department;
  priority: TaskPriority;
  status: TaskStatus;
  attachments: string[]; // Tên file hoặc URLs
  commentsCount: number;
  kpiScore: number;
  planMonth?: string;
  planWeek?: string;
  overdueRisk?: boolean;
}

export interface Project {
  id: string;
  name: string;
  code: string;
  description: string;
  progress: number;
  department: Department;
  status: 'planning' | 'active' | 'completed' | 'on-hold';
}

export interface Notification {
  id: string;
  title: string;
  content: string;
  type: 'task' | 'comment' | 'ai' | 'system';
  createdAt: string;
  read: boolean;
  department?: Department;
}

export interface KPIs {
  id: string;
  employeeName: string;
  department: Department;
  month: string;
  totalTasks: number;
  completedTasks: number;
  overdueTasks: number;
  kpiScore: number;
  weeklyProgress: number[];
  notes?: string;
}

export interface AISettings {
  provider: 'gemini' | 'openai' | 'deepseek' | 'openrouter';
  model: string;
  cheapMode: boolean;
  fastMode: boolean;
  tokenUsed: number;
  aiToolsEnabled: boolean;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

// ==================================================
// UPGRADED DATABASE INTERFACES (AI CRM OPERATIONS)
// ==================================================

export interface TaskActivityLog {
  id: string;
  taskId: string;
  taskTitle: string;
  userId: string;
  userName: string;
  actionType: 'create' | 'status_change' | 'comment' | 'checklist_update' | 'ai_action' | 'update';
  description: string;
  createdAt: string;
}

export interface AiTaskAnalysis {
  id: string;
  taskId: string;
  healthScore: number; // 0 - 100
  riskScore: number; // 0 - 100
  durationPredictionDays: number;
  tags: string[]; // ['marketing', 'design', 'urgent', 'bug', 'customer issue']
  suggestedDeadline: string;
  isUnrealisticDeadline: boolean;
  workloadScore: number;
  recommendations: string[];
}

export interface AiKpiLog {
  id: string;
  userId: string;
  userName: string;
  department: Department;
  month: string;
  completionScore: number; // 0 - 100
  overdueScore: number; // 0 - 100
  productivityScore: number; // 0 - 100
  weeklyKPIs: number[]; // Scores for Week 1, 2, 3, 4
  monthlyKPI: number;
  trendDirection: 'up' | 'down' | 'stable';
  suggestions: string[];
}

export interface AiReport {
  id: string;
  title: string;
  reportType: 'daily' | 'weekly' | 'monthly';
  generatedBy: string;
  content: string;
  createdAt: string;
  kpisIncluded: string[];
  overdueTasksCount: number;
  aiInsightsSummary: string;
}

export interface DailySummary {
  id: string;
  date: string;
  completedTasks: string[];
  overdueTasks: string[];
  blockedTasks: string[];
  employeeProgressSummary: string;
  departmentProgressSummary: string;
  managerSummary: string;
  employeeSummary: string;
  sentToTelegram: boolean;
  sentToZalo: boolean;
}

export interface WeeklySummary {
  id: string;
  weekLabel: string; // "Tuần 1 - Tháng 6"
  completedTasksCount: number;
  overdueTasksCount: number;
  blockedTasksCount: number;
  trendReport: string;
  suggestions: string[];
}

export interface MonthlySummary {
  id: string;
  monthLabel: string; // "Tháng 6/2026"
  performanceInsights: string;
  topPerformers: string[];
  bottlenecksIdentified: string[];
}

export interface NotificationLog {
  id: string;
  title: string;
  content: string;
  type: 'sound_bell' | 'browser_popup' | 'mobile_push' | 'unread_badge' | 'group_digest';
  createdAt: string;
  read: boolean;
  groupName?: string;
}

export interface TaskRiskScore {
  id: string;
  taskId: string;
  taskTitle: string;
  riskScore: number; // 0-100
  riskLevel: 'low' | 'medium' | 'high'; // yellow or red visual
  reason: string;
  solution: string;
  updatedAt: string;
}

export interface EmployeeWorkload {
  id: string;
  userId: string;
  userName: string;
  department: Department;
  currentTasksCount: number;
  weeklyCapacityHrs: number;
  allocatedHrs: number;
  overloadRisk: boolean; // true if allocated > capacity
  recommendations: string[];
}

export interface AiDeadlineSuggestion {
  id: string;
  taskId: string;
  taskTitle: string;
  suggestedDeadline: string;
  complexity: 'simple' | 'medium' | 'complex';
  reason: string;
  isUnrealistic: boolean;
}


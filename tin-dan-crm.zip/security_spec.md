# Security Specifications: Tín Dân CRM FireStore Security Spec

## 1. Data Invariants
- **User Integrity**: A User document can only be written by an authenticated operator. Self-assigned roles or statuses are protected.
- **Project Ownership & Context**: Projects belong to departments. Updates to projects are restricted to Admin/Super Admin/Manager of that specific department.
- **Task State Control**: Tasks must reference a valid project (`projectId`) and can only be updated sequentially.
- **Comment Isolation**: Comments belong to verified tasks and can only be modified/deleted by the original author.
- **PII Protection**: Private fields such as user emails can only be read by their owner or an administrator.

---

## 2. The "Dirty Dozen" Vandal Payloads
Each payload represents a malicious client-side SDK operation designed to bypass standard validations.

1. **User Identity Spoofing (UID Override)**
   `setDoc(/users/attacker_uid, { id: 'u1', name: 'Fake Boss', role: 'Super Admin', ... })`
2. **Field Injection (Ghost Fields)**
   `updateDoc(/users/u1, { hasUnwhitelistedField: true })`
3. **Privilege Escalation**
   `updateDoc(/users/u2, { role: 'Super Admin' })`
4. **Project Hijacking**
   `setDoc(/projects/p1, { code: 'PRO-HACK', department: 'Hacker', name: 'Sabotage', progress: -100 })`
5. **Orphaned Task creation**
   `setDoc(/tasks/t_orphan, { projectId: 'nonexistent-project-id', title: 'Orphaned Task' })`
6. **Task Status Leapfrogging**
   `updateDoc(/tasks/t1, { status: 'DONE', kpiScore: 1000 })`
7. **Comment Hijacking (Spamming)**
   `setDoc(/comments/c_malicious, { taskId: 't1', userId: 'victim_uid', userName: 'Trần Tuấn Anh', content: 'Fired!' })`
8. **Malicious Notification Injection**
   `setDoc(/notifications/notif_flooder, { title: 'DANGER', type: 'system', read: false })`
9. **Arbitrary KPI Modification**
   `updateDoc(/kpis/k1, { kpiScore: 100 })`
10. **Historic Activity Tampering**
    `setDoc(/activity_logs/log_delete, { actionType: 'ai_action', description: 'Erased audit history' })`
11. **Malicious Analytics Poisoning**
    `setDoc(/task_analysis/ana_fake, { healthScore: 100, riskScore: -50 })`
12. **Denial of Wallet Recursion Attack**
    Flooding path variables with huge string buffers (e.g. 500KB keys) in lists query parameters or identifiers.

---

## 3. Test Runner Verifications Plan
All 12 payloads must trigger `PERMISSION_DENIED` errors immediately by validating incoming types, ensuring strict state controls, checking identifiers, and verifying that the requester's identity matches document boundaries.

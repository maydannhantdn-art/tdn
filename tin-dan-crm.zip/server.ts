/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { AIManager } from './ai/ai-manager';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// ==========================================
// API ROOTS
// ==========================================

// 1. AI Parse Excel / CSV Plan
app.post('/api/ai/parse-excel', async (req, res) => {
  const { data } = req.body; // tabular string[][]

  if (!data || !Array.isArray(data) || data.length === 0) {
    return res.status(400).json({ success: false, message: 'Dữ liệu đầu vào không hợp lệ hoặc trống.' });
  }

  const payloadString = JSON.stringify(data);

  try {
    const systemPrompt = `Bạn là trợ lý AI thông minh thiết lập trên Tín Dân CRM.
Hãy phân tích ma trận dữ liệu sau được import từ file Excel hoặc CSV kế hoạch tổng của công ty Tín Dân.

Hãy lọc ra tất cả các dòng chứa thông tin công việc, thực hiện việc gom nhóm, ánh xạ cột phù hợp, tự động tính toán 'overdueRisk' (khả năng quá hạn dựa trên mức độ ưu tiên và hạn chót), tính điểm KPI (thường từ 5 - 30 điểm), tạo checklist công việc phụ chi tiết (ít nhất 2-3 gạch đầu dòng) và ước lượng độ tin cậy AI tự tin (AI confidence score từ 0.0 đến 1.0).

Vui lòng trả về định dạng JSON thuần chứa danh sách các đầu mục công việc được ánh xạ chuẩn có định dạng chính xác sau đây:
{
  "confidenceScore": 0.95,
  "tasks": [
    {
      "projectName": "Tên Dự Án",
      "planMonth": "Tháng...",
      "planWeek": "Tuần...",
      "title": "Tên công việc",
      "description": "Mô tả...",
      "assignee": "Tên nhân sự thực hiện",
      "department": "Bộ phận ví dụ: Marketing, CSKH, Kỹ thuật",
      "priority": "Low hoặc Medium hoặc High",
      "deadline": "YYYY-MM-DD",
      "kpiScore": 15,
      "checklist": ["việc con 1", "việc con 2"]
    }
  ]
}`;

    const textResult = await AIManager.runAIChatCompletion([
      { role: 'system', content: systemPrompt },
      { role: 'user', content: `Dữ liệu ma trận Excel:\n${payloadString}` }
    ], true);

    const parsedJson = JSON.parse(textResult);
    return res.json({ success: true, aiGenerated: true, parsed: parsedJson });
  } catch (error: any) {
    console.error("Error during real AI excel analysis, falling back to simulator:", error);
  }

  // --- High-Fidelity Simulation Fallback ---
  setTimeout(() => {
    // Let's parse columns and dynamically draft simulated tasks based on what the user inputted
    const headers = data[0] || [];
    const rows = data.slice(1);

    const matchCol = (names: string[]) => {
      return headers.findIndex(h => names.some(n => String(h).toLowerCase().includes(n.toLowerCase())));
    };

    const projIdx = matchCol(['project', 'dự án']);
    const taskIdx = matchCol(['task', 'công việc', 'đầu việc', 'nhiệm vụ']);
    const descIdx = matchCol(['desc', 'mô tả', 'nội dung']);
    const assignIdx = matchCol(['assign', 'người', 'nhân viên']);
    const deptIdx = matchCol(['dept', 'phòng', 'bộ phận']);
    const priIdx = matchCol(['priority', 'ưu tiên']);
    const deadIdx = matchCol(['dead', 'hạn', 'deadline']);
    const kpiIdx = matchCol(['kpi', 'score', 'điểm']);

    const mockTasks = rows.map((row, i) => {
      const proj = projIdx !== -1 ? row[projIdx] : 'Dự án Tín Dân';
      const title = taskIdx !== -1 ? row[taskIdx] : 'Công việc ' + (i + 1);
      const desc = descIdx !== -1 ? row[descIdx] : 'Mô tả chi tiết của ' + title;
      const assignee = assignIdx !== -1 ? row[assignIdx] : 'Nguyễn Văn Nam';
      const dept = deptIdx !== -1 ? row[deptIdx] : 'Marketing';
      const priority = priIdx !== -1 ? row[priIdx] : 'Medium';
      const deadline = deadIdx !== -1 ? row[deadIdx] : '2026-06-12';
      const kpi = kpiIdx !== -1 ? parseInt(row[kpiIdx]) || 10 : 12;

      return {
        projectName: proj || 'Khác',
        planMonth: 'Tháng 6',
        planWeek: 'Tuần 2',
        title: title || 'Nhiệm vụ mới',
        description: desc || 'Chưa cập nhật chi tiết',
        assignee: assignee || 'Trần Tuấn Anh',
        department: dept || 'Sale',
        priority: priority || 'Medium',
        deadline: deadline || '2026-06-15',
        kpiScore: kpi,
        checklist: [
          'Thu thập tệp mẫu yêu cầu tương tác',
          'Triển khai nội dung thực thi mẫu phác thảo',
          'Nộp báo cáo cho sếp duyệt trực tiếp'
        ]
      };
    });

    res.json({
      success: true,
      aiGenerated: false,
      parsed: {
        confidenceScore: 0.94,
        tasks: mockTasks.length > 0 ? mockTasks : [
          {
            projectName: 'Kế hoạch Tem Vivian Q2',
            planMonth: 'Tháng 6',
            planWeek: 'Tuần 1',
            title: 'Tối ưu hóa file thiết kế in decal cuộn',
            description: 'Tải tài liệu mẫu của Vivian cung cấp bám sát các chỉ số in ấn xưởng',
            assignee: 'Phạm Minh Hải',
            department: 'Kỹ thuật',
            priority: 'High',
            deadline: '2026-06-12',
            kpiScore: 15,
            checklist: ['Tải tài liệu về', 'Cân chỉnh thông số màu sắc in', 'Xuất file test']
          }
        ]
      }
    });
  }, 1000);
});

// 2. AI Executive Dashboard & KPI Reporting Analysis
app.post('/api/ai/generate-summary', async (req, res) => {
  const { tasks, kpis, reportType } = req.body;
  const currentType = reportType || 'weekly';
  const typeLabel = currentType === 'daily' ? 'NGÀY' : currentType === 'weekly' ? 'TUẦN' : 'THÁNG';

  const summaryPrompt = `Bạn là Trưởng bộ phận Chiến lược & CRO cấp cao của công ty Tín Dân (Tín Dân CRM).
Hãy viết một bản BÁO CÁO PHÂN TÍCH HIỆU SUẤT THEO ${typeLabel} và định hướng tăng trưởng nhanh cho ban giám đốc xem bao gồm:
1. ĐÁNH GIÁ NĂNG LỰC: Tổng quan kết quả thực hiện của đội ngũ phòng ban trong ${typeLabel} này (Chỉ rõ phần trăm hoàn thành, số lượng đầu việc chưa chạy).
2. NHẬN DIỆN ĐIỂM NGHẼN: Phát hiện các nút thắt cổ chai trực tiếp (Nhân sự quá tải, rủi ro trễ tiến độ sấy UV Tem Vivian).
3. ĐỀ XUẤT GROWTH HACKING: Gợi ý ít nhất 3 hành động thực tiễn để tăng ROI, đẩy nhanh sản xuất mà không tốn kém chi phí.

QUY TẮC PHONG CÁCH BẮT BUỘC:
- TUYỆT ĐỐI KHÔNG Sử dụng bất kỳ ký tự định dạng markdown nào (như các dấu **, *, #, -, v.v...).
- Hãy dùng dấu xuống dòng, chữ in hoa cho tiêu đề đề mục, các ký tự unicode đơn giản nếu cần. Trả về văn bản thuần túy (plain text) 100%.`;

  try {
    const textResult = await AIManager.runAIChatCompletion([
      { role: 'system', content: summaryPrompt },
      { role: 'user', content: `Dữ liệu công việc trực quan: ${JSON.stringify(tasks)}. Dữ liệu KPIs phòng ban: ${JSON.stringify(kpis)}` }
    ], false);

    // Clean any accidental markdown leftovers
    const cleaned = textResult
      .replace(/[*#_\-`>]/g, '')
      .replace(/\[\s*\]/g, '')
      .trim();

    return res.json({ success: true, aiGenerated: true, summary: cleaned });
  } catch (err) {
    console.error("AI summary error: ", err);
  }

  // --- High-Fidelity Simulation Fallback (Cleaned of Markdown) ---
  const completed = tasks.filter((t: any) => t.status === 'Done').length;
  const overdue = tasks.filter((t: any) => t.overdueRisk).length;

  const simulationSummary = `BÁO CÁO THỰC CHIẾN AI INSIGHTS VÔ CÙNG CHI TIẾT - LOẠI BÁO CÁO: ${typeLabel}
  
Kính gửi Sếp Trần Tuấn Anh và Ban lãnh đạo Tín Dân Company,

Dưới đây là chẩn đoán nhanh về hiệu năng vận hành và giải pháp tối ưu hóa chuyển đổi tự động từ Hệ thống AI của Tín Dân CRM:

1. ĐÁNH GIÁ HIỆU LỰC VẬN HÀNH PHÒNG BAN:
+ Tổng điểm hoàn thành: Đạt ${completed}/${tasks.length} đầu việc chủ chốt.
+ Tỷ lệ trễ hạn hiện tại: Chiếm trường hợp tương đối thấp. Phòng Kỹ thuật và Sales đang phát sinh hiện tượng nghẽn nhẹ định kỳ vào cuối tuần.
+ Chỉ số KPI xuất sắc nhất: Thuộc về phòng CSKH (Phạm Minh Hải) và phòng Marketing (Nguyễn Văn Nam) nhờ tối ưu hóa quy trình tin nhắn tự động.

2. NHẬN DIỆN RỦI RO VÀ NÚT THẮT CỔ CHAI (BOTTLENECKS):
+ Các nhiệm vụ liên quan đến máy in cuộn UV tại xưởng Tem Vivian cần được phân bổ đều hơn. Việc bảo dưỡng máy bị trễ là rủi ro trực tiếp ảnh hưởng đến chỉ số chuyển đổi sản lượng in nhãn tuần kế tiếp.
+ Chiến dịch Marketing Bao bì VF5 đang chuyển biến tốt, tuy nhiên mảng Facebook Ads cần phân bổ mục tiêu sâu hơn tới tệp khách hàng xưởng chế dược và xưởng bánh kẹo nội địa để tăng ROI mục tiêu.

3. 03 GIẢI PHÁP ĐỘT PHÁ GROWTH HACKING XUẤT SẮC:
+ Thiết lập Cảnh báo Quá hạn Sớm (Early Alerts): Tự động nhắc nhở trước 24 giờ cho nhân sự có công việc khẩn cấp.
+ Chuẩn hóa Thiết kế Tem Nhãn: Tạo sẵn các layout mẫu tại Tem Vivian để giảm thời gian thiết kế từ 48 giờ xuống dưới 4 giờ.
+ Phân phối Tài nguyên Chéo: Huy động CSKH hỗ trợ tư vấn tức thời các lead nóng đổ về từ Facebook Ads để tránh nguội khách hàng.

Hệ thống CRM thông minh đã sẵn sàng hỗ trợ sếp phê duyệt điều chuyển nhân sự chỉ với các thao tác trực tiếp!`;

  res.json({ success: true, aiGenerated: false, summary: simulationSummary });
});

// 2.1. AI Split Task Engine
app.post('/api/ai/split-task', async (req, res) => {
  const { title, department } = req.body;
  if (!title) {
    return res.status(400).json({ success: false, message: 'Thiếu tiêu đề công việc.' });
  }

  const prompt = `Bạn là Trợ lý AI đặc biệt của Tín Dân Company (đơn vị cung cấp Tem Vivian, Decal bóng, in dập UV sấy).
Hãy phân tích tiêu đề công việc: "${title}" trực thuộc phòng ban "${department || 'Chung'}".
Hãy thực hiện rã tách (split) nhiệm vụ này thật thông minh. Trả về định dạng JSON chứa:
1. description: Một đoạn mô tả chi tiết, thực tế, bám sát chuyên môn của phòng ban và định dạng xưởng in, dài khoảng 2-3 câu thể hiện định hướng Growth Hacking.
2. checklistText: Danh sách gồm 3-4 đầu mục nhiệm vụ con (checklist) cách nhau bằng dấu xuống dòng (\\n), liên quan trực tiếp và bổ trợ hoàn hảo cho tiêu đề công việc này. Các dòng KHÔNG bắt đầu bằng số thứ tự.
3. kpiScore: Điểm số KPI đánh giá độ khó mẫu (từ 5 đến 40 điểm).

Ví dụ định dạng trả về:
{
  "description": "...",
  "checklistText": "...",
  "kpiScore": 15
}`;

  try {
    const textResult = await AIManager.runAIChatCompletion([
      { role: 'user', content: prompt }
    ], true);

    const parsedData = JSON.parse(textResult);
    return res.json({ success: true, aiGenerated: true, data: parsedData });
  } catch (error) {
    console.error("Split task error with AI:", error);
  }

  // Fallback
  const fallbackDesc = `Dự án nhãn in Tín Dân Q2 | Công việc bóc tách thông minh cho phòng ${department || 'Hành chính'}: "${title}". Đáp ứng trực tiếp mục tiêu hoàn thiện đơn hàng bao bì & Tem Vivian chất lượng cao.`;
  const fallbackChecklist = `Chuẩn bị tài liệu kỹ thuật liên quan đến ${title}\nTriển khai phương án hành động & phối hợp liên phòng ban\nĐo lường hiệu quả vận hành và báo cáo sếp Tuấn Anh phê duyệt`;
  return res.json({
    success: true,
    aiGenerated: false,
    data: {
      description: fallbackDesc,
      checklistText: fallbackChecklist,
      kpiScore: 15
    }
  });
});

// 2.2. AI Suggest Checklist Engine
app.post('/api/ai/suggest-checklist', async (req, res) => {
  const { title, department } = req.body;
  const prompt = `Yêu cầu viết checklist chi tiết gồm 4 việc cần làm cụ thể cho công việc: "${title}" thuộc bộ phận "${department}". 
  Hãy viết cực kỳ sát nội dung công việc và chuyên môn thực tế của công ty in ấn Tín Dân / Tem Vivian, không nói lý thuyết sáo rỗng.
  QUY TẮC BẮT BUỘC: 
  1. Trả về đúng 4 dòng, mỗi dòng là một đầu việc cụ thể.
  2. KHÔNG ghi số thứ tự ở đầu dòng, KHÔNG gạch đầu dòng, KHÔNG dùng các ký tự markdown như *, -, #, **.
  Trả về text thuần túy chỉ có chữ và dòng mới.`;

  try {
    const textResult = await AIManager.runAIChatCompletion([
      { role: 'user', content: prompt }
    ], false);
    
    // Clean any accidental markdown / bullet prefixes
    const cleaned = textResult
      .split('\n')
      .map(line => line.replace(/^[\s*\-•\d.]+\s*/, '').trim())
      .filter(line => line.length > 0)
      .join('\n');
      
    return res.json({ success: true, aiGenerated: true, checklistText: cleaned || textResult.trim() });
  } catch (error) {
    console.error("Suggest checklist error with AI:", error);
  }

  // Fallback dựa trên bộ phận
  let listText = '';
  switch (department) {
    case 'Marketing':
      listText = `Nghiên cứu thị trường và đối thủ cho ${title}\nThiết kế ấn phẩm marquette nhãn dán\nSet up Ads phân khúc hướng mục tiêu\nĐo lường ROI chiến dịch`;
      break;
    case 'Kỹ thuật':
      listText = `Kiểm tra linh kiện máy móc phục vụ ${title}\nCân chỉnh đèn sấy UV cuộn và chạy thử\nKhắc phục sự cố kỹ thuật phát sinh\nBáo cáo nghiệm thu kỹ thuật lên sếp`;
      break;
    default:
      listText = `Bóc tách nhiệm vụ đầu việc chi tiết cho ${title}\nTriển khai phối hợp nhân sự liên phòng ban\nKiểm định chất lượng sản phẩm Tem Vivian\nNộp báo cáo trực tiếp gửi ban điều hành`;
      break;
  }
  return res.json({ success: true, aiGenerated: false, checklistText: listText });
});

// 3. AI Assistant Chat
app.post('/api/ai/chat', async (req, res) => {
  const { messages, currentDataState } = req.body;

  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ success: false, message: 'Danh sách tin nhắn không hợp lệ.' });
  }

  const systemInstruction = `Bạn là Trợ lý Trí tuệ Nhân tạo Cao cấp Tín Dân AI (CRM Tín Dân) - đóng vai trò là Cố vấn Vận hành kiêm Growth Hacker xuất sắc.
Bạn trả lời sếp Trần Tuấn Anh và các nhân viên công ty Tín Dân cực kỳ thông minh, tình cảm, am hiểu sâu về hoạt động kinh doanh (In ấn Tem Vivian, Decal, mác dán bao bì, nhãn mẫu công nghiệp).

Thông tin Trực quan về Hệ thống hiện tại của Tín Dân CRM:
- Dự án hiện hành: ${JSON.stringify(currentDataState?.projects || [])}
- Các nhiệm vụ hoạt động: ${JSON.stringify(currentDataState?.tasks || [])}
- Danh sách nhân sự: ${JSON.stringify(currentDataState?.users || [])}

Quy tắc giao tiếp và xử sự bắt buộc:
1. Xưng 'Em' và gọi người dùng là 'Sếp' hoặc 'Anh/Chị'.
2. KHÔNG GIÁO HUẤN ĐẠO LÝ. Rất thực tế, tập trung giải quyết công việc siêu nhanh, gọn gàng, giảm thiểu thao tác click.
3. Nếu sếp yêu cầu tạo một công việc mới hoặc phân bổ KPI, hãy trực tiếp gợi ý nội dung tối ưu dạng cấu trúc rõ ràng: Tông màu, Tiêu đề, Mô tả, Người thực hiện, Phòng ban.
4. Mang phong cách của một chiến binh Growth Hacker thực thụ - luôn đưa ra các đề xuất đột phá về ROI, CPL và tăng tốc sản xuất.
5. QUY TẮC CỰC KỲ QUAN TRỌNG: TUYỆT ĐỐI KHÔNG Sử dụng bất kỳ ký tự markdown nào như **, *, #, -, v.v... Hãy viết bằng văn bản thuần túy (plain text) có xuống dòng rõ ràng để người dùng dễ quan sát trực quan. Không dùng ký tự hoa mỹ hay dấu gạch đầu dòng dạng markdown.`;

  try {
    const formattedMessages = [
      { role: 'system', content: systemInstruction },
      ...messages.map(m => ({
        role: m.sender === 'user' ? 'user' : 'assistant',
        content: m.content
      }))
    ];

    const textResult = await AIManager.runAIChatCompletion(formattedMessages, false);
    return res.json({ success: true, aiGenerated: true, response: textResult });
  } catch (err) {
    console.error("AI Chat error: ", err);
  }

  // --- High-Fidelity Simulator Response ---
  const lastUserMsg = messages[messages.length - 1]?.content || '';
  let responseText = '';

  const queryLower = lastUserMsg.toLowerCase();
  if (queryLower.includes('tạo task') || queryLower.includes('phân công') || queryLower.includes('giao việc')) {
    responseText = `Dạ sếp, em đã định hình cấu trúc nhiệm vụ tăng trưởng tuyệt vời dựa trên tình hình xưởng Tem Vivian hiện tại ạ:
    
**Đề xuất Công việc đề cử:**
* **Tên Công việc:** Triển khai ưu đãi mẫu nhãn dán Q2 cho khách hàng thực phẩm.
* **Mô tả:** Thiết lập trang đích và tệp quà tặng mẫu nhãn in chất lượng cho đại lý để tối ưu hóa chuyển đổi.
* **Phòng ban:** Marketing
* **Người gánh vác:** Nguyễn Văn Nam
* **Ưu tiên:** High
* **Hạn chót:** 2026-06-12

*Sếp có thể bấm ngay nút "Tạo nhanh công việc bằng AI" tại module Công việc để lưu trực tiếp đầu việc này vô hệ thống chỉ trong 1 nốt nhạc ạ!*`;
  } else if (queryLower.includes('kpi') || queryLower.includes('báo cáo') || queryLower.includes('phân tích')) {
    responseText = `Dạ thưa Sếp, em vừa chạy bộ phân tích dữ liệu tổng quan cho phòng ban Tín Dân:
    
* **Phòng CSKH (Phạm Minh Hải)** đạt hiệu ứng KPI rực rỡ nhất: **92%** nhờ cải tiến kịch bản Zalo ZNS tự động.
* **Phòng Kỹ thuật** cần chú trọng bảo dưỡng thiết bị kịp thời để bảo toàn tốc độ giao hàng.
* **Đề xuất của em:** Sếp có thể phê duyệt thưởng nóng cho CSKH để thúc đẩy không khí chiến đấu của xưởng sản xuất Tem Vivian trong tháng này ạ!`;
  } else {
    responseText = `Dạ sếp, Tín Dân AI xin nghe! Em luôn túc trực để hỗ trợ sếp quản lý tối cao các mảng công việc tại công ty. 

Sếp có thể bảo em:
1. *"Tạo task marketing chạy chiến dịch decal"*
2. *"Phân tích hiệu suất KPI và trễ hạn"*
3. *"Đề xuất kế hoạch tối ưu sản lượng xưởng tem Vivian"*

Em cam kết phản hồi siêu tốc, không rườm rà đạo lý, tập trung nâng tầm ROI cao nhất cho công ty mình ạ!`;
  }

  res.json({ success: true, aiGenerated: false, response: responseText });
});


// ==========================================
// VITE OR STATIC INGRESS HANDLER
// ==========================================

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
    console.log("Vite development server mounted gracefully.");
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
    console.log("Serving production bundle from:", distPath);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[TÍN DÂN CRM SERVER] Running on port http://0.0.0.0:${PORT}`);
  });
}

startServer();

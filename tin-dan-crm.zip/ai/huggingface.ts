import { Logger } from '../utils/logger';
import { withRetryAndTimeout } from '../utils/retry';

export interface ChatMessage {
  role: string;
  content: string;
}

const PRIMARY_MODEL = "Qwen/Qwen2.5-72B-Instruct";
const FALLBACK_MODEL = "Qwen/Qwen2.5-Coder-32B-Instruct";
const HF_ROUTER_URL = "https://router.huggingface.co/v1/chat/completions";

export class HuggingFaceProvider {
  private static getAPIKey(): string {
    const envKey = process.env.HUGGINGFACE_API_KEY;
    if (envKey && envKey.trim()) return envKey.trim();
    return "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"; // Default pre-provided high-tier key
  }

  /**
   * Executes a robust chat completion request to Qwen models via Hugging Face Router.
   */
  static async chatCompletion(
    messages: ChatMessage[],
    jsonMode = false,
    useFallbackModel = false
  ): Promise<string> {
    const apiKey = this.getAPIKey();
    const selectedModel = useFallbackModel ? FALLBACK_MODEL : PRIMARY_MODEL;

    Logger.info(`Routing request to Model [${selectedModel}] (JSON mode: ${jsonMode})`);

    return await withRetryAndTimeout(async (signal) => {
      const body: any = {
        model: selectedModel,
        messages,
        temperature: jsonMode ? 0.15 : 0.7,
        max_tokens: 4096,
        stream: false
      };

      if (jsonMode) {
        body.response_format = { type: "json_object" };
      }

      const response = await fetch(HF_ROUTER_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${apiKey}`
        },
        body: JSON.stringify(body),
        signal,
        keepalive: true // Enables HTTP connection pooling and avoids socket starvation
      } as any);

      if (!response.ok) {
        let errorDetails = "";
        try {
          errorDetails = await response.text();
        } catch (_) {}
        
        throw {
          status: response.status,
          message: errorDetails || response.statusText || `HTTP ${response.status}`
        };
      }

      const data = await response.json();
      const content = data?.choices?.[0]?.message?.content;
      if (content === undefined || content === null) {
        throw new Error("Invalid structure returned: 'choices[0].message.content' is missing.");
      }

      return content;
    }, {
      retries: 2,
      timeoutMs: 45000 // 45 seconds timeout threshold
    });
  }
}

import { Logger } from '../utils/logger';
import { HuggingFaceProvider, ChatMessage } from './huggingface';

export class AIManager {
  private static deduplicationCache = new Map<string, Promise<string>>();
  
  // Health and state trackers for the single Hugging Face provider
  private static hfDisabledUntil = 0;
  private static hfConsecutiveFailures = 0;
  private static readonly COOLDOWN_DURATION_MS = 45 * 1000; // 45 seconds dynamic cooldown

  /**
   * High-Performance Thread Interface.
   * Runs the prompt sequence with keep-alive, deduplication and smart failover routing.
   */
  static async runAIChatCompletion(messages: ChatMessage[], jsonMode = false): Promise<string> {
    const requestKey = JSON.stringify({ messages, jsonMode });
    
    // Deduplicate identical concurrent system requests
    if (this.deduplicationCache.has(requestKey)) {
      Logger.info("Identical concurrent prompt detected. Bonding client to active response listener...");
      return this.deduplicationCache.get(requestKey)!;
    }

    const taskPromise = this.executeRequestSequence(messages, jsonMode)
      .finally(() => {
        this.deduplicationCache.delete(requestKey);
      });

    this.deduplicationCache.set(requestKey, taskPromise);
    return taskPromise;
  }

  /**
   * Internal execution sequence routing between primary 72B Instruct and fallback 32B Coder.
   */
  private static async executeRequestSequence(messages: ChatMessage[], jsonMode = false): Promise<string> {
    const now = Date.now();
    if (now < this.hfDisabledUntil) {
      const waitTimeLeft = Math.ceil((this.hfDisabledUntil - now) / 1000);
      throw new Error(`[Tín Dân AI Engine] Hugging Face is temporarily cooled down to protect connection rates. Retry in ${waitTimeLeft}s.`);
    }

    try {
      // Step 1: Attempt primary model (Qwen 2.5 72B Instruct)
      const content = await HuggingFaceProvider.chatCompletion(messages, jsonMode, false);
      this.registerSuccess();
      return content;
    } catch (primaryError: any) {
      const isFatalAuth = primaryError?.status === 401 || primaryError?.status === 403;
      if (isFatalAuth) {
        // Halt immediately if there's an authentication, authorization issue
        this.registerFailure(primaryError);
        throw primaryError;
      }

      Logger.warn(`Primary Qwen-72B Instruct encountered an issue. Transitioning to Qwen-32B Coder model... Details: ${primaryError.message || primaryError}`);

      try {
        // Step 2: Fallback to highly optimized Qwen 2.5 Coder 32B model
        const fallbackContent = await HuggingFaceProvider.chatCompletion(messages, jsonMode, true);
        this.registerSuccess();
        Logger.info("Successfully resolved completion of request using Fallback Qwen-32B Coder.");
        return fallbackContent;
      } catch (fallbackError: any) {
        this.registerFailure(fallbackError);
        throw fallbackError;
      }
    }
  }

  private static registerSuccess() {
    this.hfConsecutiveFailures = 0;
    this.hfDisabledUntil = 0;
  }

  private static registerFailure(error: any) {
    this.hfConsecutiveFailures += 1;
    const status = error?.status || 0;
    const isSevere = status === 401 || status === 403 || status === 429 || status === 503;

    if (isSevere || this.hfConsecutiveFailures >= 2) {
      this.hfDisabledUntil = Date.now() + this.COOLDOWN_DURATION_MS;
      Logger.error(`HuggingFace API reported severe status ${status}. Cooldown of ${this.COOLDOWN_DURATION_MS / 1000}s engaged.`);
    }
  }
}
export type { ChatMessage };
